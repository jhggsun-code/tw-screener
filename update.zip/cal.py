"""市場日曆（台股結算日、美股三巫日、重要數據、財報）與景氣循環提示 → docs/cal.json"""
import re, time, urllib.parse, email.utils, datetime as dt
import numpy as np, pandas as pd, requests, yfinance as yf
from extras import UA, TZ, _rsi

WD = "一二三四五六日"
KIND = {  # 種類: (標籤, 這是什麼, 對股市的可能影響, 重要度)
    "settle": ("台指期月結算", "每月第三個星期三，台指期貨與選擇權月契約到期結算（遇休市順延）。每週三另有週選擇權到期。",
               "結算前後成交量與波動常放大，法人換倉與結算價攻防可能造成指數短線震盪；單日大漲大跌不一定代表趨勢改變。", 3),
    "witch": ("美股三巫日", "每年 3、6、9、12 月第三個星期五：股價指數期貨、指數選擇權、個股選擇權同日到期，也是 S&P 指數成分股季度調整生效日。",
              "成交量常明顯放大、尾盤波動大；被調入或調出指數的個股可能出現額外買賣壓，隔週通常回到正常量能。", 4),
    "opex": ("美股月選擇權到期", "每月第三個星期五，美股月選擇權到期（非季底月份）。", "到期前後部位調整可能使個股與指數短線波動放大，影響通常小於三巫日。", 2),
    "fomc": ("FOMC 利率決策", "美國聯準會公開市場委員會的利率決策日（台灣時間隔天凌晨約 02:00 公布，並有主席記者會）。",
             "利率與談話語氣影響全球資金成本：偏鴿（降息／暫停升息）通常有利成長股與科技股；偏鷹則壓抑估值，也會影響美元與外資在台股的資金流向。重點看利率路徑，不只看當次決定。", 5),
    "minutes": ("FOMC 會議紀錄", "聯準會公布上次利率會議的詳細討論紀錄。", "可看出官員對降息／升息的分歧，常造成短線預期調整。", 3),
    "nfp": ("美國非農就業報告", "美國勞工統計局公布上月新增非農就業人數、失業率與薪資成長（台灣時間當晚 20:30 或 21:30）。",
            "好於預期：經濟強勁但可能降低降息預期，成長股承壓；差於預期：引發衰退疑慮但可能提高降息預期。重點是「與預期的差距」、失業率與薪資成長。", 5),
    "cpi": ("美國 CPI 通膨", "美國消費者物價指數，反映民生物價變化（台灣時間當晚 20:30 或 21:30）。",
            "高於預期：降息預期降溫，科技與成長股常承壓、美元走強；低於預期：有利降息預期與成長股。核心 CPI 比整體 CPI 更受關注。", 5),
    "ppi": ("美國 PPI 生產者物價", "美國生產者物價指數，反映企業端成本，常被視為 CPI 的領先參考。", "數字偏高會強化通膨壓力的擔憂，影響降息預期。", 3),
    "earn": ("財報／法說會", "公司公布季度財報並召開法說會（美股多數在盤後）。",
             "重點是營收與 EPS 是否優於預期、未來財測與資本支出。「利多出盡」與「利空出盡」都很常見，股價反應取決於預期差，而不只是好壞。", 4),
    "cbc": ("台灣央行理監事會", "台灣央行每季（3、6、9、12 月）召開理監事會議，決定政策利率與匯率政策（日期為預估，以央行公告為準）。",
            "影響金融股、營建股與新台幣走勢；升息通常有利銀行利差、不利營建與高估值股。", 4),
    "rev": ("上市櫃月營收公布截止", "上市櫃公司須在每月 10 日前公布上月營收。", "月營收是台股短線題材來源，營收年增、月增創高的公司常受關注；也是檢驗法說會展望的依據。", 2),
    "fin": ("財報申報截止", "上市櫃公司季報／年報的法定申報期限（Q1 5/15、半年報 8/14、Q3 11/14、年報 3/31）。",
            "截止日前後是財報與 EPS 集中公布期，個股可能因獲利好壞出現較大波動。", 3),
    "ndc": ("景氣對策信號公布", "國發會每月底前後公布上月景氣對策信號（約每月 26～30 日，日期為預估）。", "燈號反映景氣冷熱，紅燈代表熱絡、藍燈代表低迷，是判斷景氣循環位置的參考。", 3),
    "thol": ("台股休市", "台灣證交所休市日。", "連假前後常量縮；休市期間國際盤的波動會在復市首日一次反映（跳空）。", 2),
    "ushol": ("美股休市", "美國股市休市（或提早收盤）。", "休市日前後量縮；台灣隔天早盤沒有美股隔夜收盤可參考。", 2),
}

def nth_wd(y, m, wd, n):
    d = dt.date(y, m, 1); d += dt.timedelta((wd - d.weekday()) % 7)
    return d + dt.timedelta(7 * (n - 1))

def months(today, horizon):
    out, d = [], dt.date(today.year, today.month, 1)
    while d <= today + dt.timedelta(horizon):
        out.append((d.year, d.month)); d = (d.replace(day=28) + dt.timedelta(8)).replace(day=1)
    return out

def get_bls():
    out = set()
    try:
        txt = requests.get("https://www.bls.gov/schedule/news_release/bls.ics", headers=UA, timeout=30).text
        for blk in txt.split("BEGIN:VEVENT")[1:]:
            s = re.search(r"SUMMARY:(.*)", blk); d = re.search(r"DTSTART[^:]*:(\d{8})", blk)
            if not (s and d):
                continue
            s = s.group(1).strip(); k = None
            if s.startswith("Employment Situation"): k = "nfp"
            elif s.startswith("Consumer Price Index"): k = "cpi"
            elif s.startswith("Producer Price Index"): k = "ppi"
            if k:
                out.add((dt.datetime.strptime(d.group(1), "%Y%m%d").date(), k))
    except Exception as e:
        print("BLS 行事曆失敗，改用內建日期", e)
    for y, m, d, k in [(2026, 11, 6, "nfp"), (2026, 11, 10, "cpi"), (2026, 12, 4, "nfp"), (2026, 12, 10, "cpi"), (2026, 12, 15, "ppi")]:
        out.add((dt.date(y, m, d), k))
    return out

def tw_holidays(today, end):
    out = []
    try:
        for x in requests.get("https://openapi.twse.com.tw/v1/holidaySchedule/holidaySchedule", timeout=30).json():
            s = str(x.get("Date", "")).strip()
            d = dt.date(int(s[:3]) + 1911, int(s[3:5]), int(s[5:7])) if len(s) == 7 else dt.datetime.strptime(s, "%Y%m%d").date()
            desc = x.get("Description") or ""
            if today <= d <= end and ("無交易" in desc or "休市" in desc or "放假" in desc or not desc):
                out.append((d, x.get("Name") or "休市", desc))
    except Exception as e:
        print("台股休市日略過", e)
    return out

def us_holidays(y):
    try:
        from dateutil.easter import easter
        gf = easter(y) - dt.timedelta(2)
    except Exception:
        gf = None
    def obs(d):
        return d - dt.timedelta(1) if d.weekday() == 5 else d + dt.timedelta(1) if d.weekday() == 6 else d
    h = [(obs(dt.date(y, 1, 1)), "新年"), (nth_wd(y, 1, 0, 3), "馬丁路德金恩日"), (nth_wd(y, 2, 0, 3), "總統日"),
         (dt.date(y, 5, 31) - dt.timedelta((dt.date(y, 5, 31).weekday()) % 7), "陣亡將士紀念日"), (obs(dt.date(y, 6, 19)), "六月節"),
         (obs(dt.date(y, 7, 4)), "獨立紀念日"), (nth_wd(y, 9, 0, 1), "勞動節"), (nth_wd(y, 11, 3, 4), "感恩節"),
         (obs(dt.date(y, 12, 25)), "聖誕節")]
    if gf: h.append((gf, "耶穌受難日"))
    h.append((nth_wd(y, 11, 3, 4) + dt.timedelta(1), "感恩節翌日（提早收盤 01:00 PM ET）"))
    return h

def build_events(today, us_items, budget=150):
    end = today + dt.timedelta(75); ev = []
    def add(d, k, m, n=None, note=""):
        if today - dt.timedelta(1) <= d <= end:
            lab, what, imp_txt, imp = KIND[k]
            ev.append(dict(d=d.isoformat(), wd=WD[d.weekday()], k=k, m=m, n=n or lab, w=what + note, x=imp_txt, imp=imp))
    for y, mo in months(today, 75):
        add(nth_wd(y, mo, 2, 3), "settle", "TW")
        add(dt.date(y, mo, 10), "rev", "TW")
        add(dt.date(y, mo, 27), "ndc", "TW", note="（約）")
        if mo in (3, 6, 9, 12):
            add(nth_wd(y, mo, 3, 3), "cbc", "TW")
            add(nth_wd(y, mo, 4, 3), "witch", "US", note="（台股：同日外資期貨部位可能調整）")
        else:
            add(nth_wd(y, mo, 4, 3), "opex", "US")
        for (mm, dd) in ((5, 15), (8, 14), (11, 14), (3, 31)):
            if mo == mm:
                add(dt.date(y, mm, dd), "fin", "TW")
    for d, name, desc in tw_holidays(today, end):
        add(d, "thol", "TW", n="台股休市：" + name, note=("（" + desc + "）") if desc else "")
    for y in {today.year, end.year}:
        for d, name in us_holidays(y):
            add(d, "ushol", "US", n="美股休市／提早收盤：" + name)
    for (y, mo, d, nm, note) in [(2026, 10, 28, "FOMC 利率決策", "（10/27–28）"), (2026, 12, 9, "FOMC 利率決策＋經濟預測", "（12/8–9，含點陣圖）"),
                                 (2027, 1, 27, "FOMC 利率決策", "（預定，1/26–27）"), (2027, 3, 17, "FOMC 利率決策＋經濟預測", "（預定，3/16–17）")]:
        add(dt.date(y, mo, d), "fomc", "US", n=nm, note=note)
    add(dt.date(2026, 11, 18), "minutes", "US"); add(dt.date(2026, 12, 30), "minutes", "US")
    for d, k in get_bls():
        add(d, k, "US")
    # 財報（追蹤的美股）
    results, t0 = [], time.time()
    dates = us_items.get("dates", []) if us_items else []
    for x in (us_items or {}).get("items", []):
        if time.time() - t0 > budget:
            print("財報資料已達時間上限，其餘略過"); break
        s, tk = x["sym"], yf.Ticker(x["sym"])
        try:
            cal = tk.calendar; eds = cal.get("Earnings Date") if isinstance(cal, dict) else None
            if eds:
                d = eds[0] if isinstance(eds, (list, tuple)) else eds
                d = d.date() if hasattr(d, "date") else d
                nm = "台積電法說會（ADR 財報日）" if s == "TSM" else f"{x['n']}（{s}）財報"
                add(d, "earn", "TW" if s == "TSM" else "US", n=nm)
        except Exception:
            pass
        try:
            df = tk.get_earnings_dates(limit=6)
            for ts, row in df.iterrows():
                d = ts.date()
                if pd.isna(row.get("Reported EPS")) or not (today - dt.timedelta(60) <= d <= today):
                    continue
                est, act, sur = row.get("EPS Estimate"), row.get("Reported EPS"), row.get("Surprise(%)")
                rx = None
                mm = d.strftime("%m-%d")
                if mm in dates:
                    i = len(dates) - 1 - dates[::-1].index(mm); h = x["hist"]; off = len(h) - len(dates)
                    j = i + off
                    if 1 <= j < len(h) - 1:
                        rx = round((h[j + 1] / h[j - 1] - 1) * 100, 2)
                results.append(dict(sym=s, n=x["n"], d=d.isoformat(), est=None if pd.isna(est) else round(float(est), 2), act=round(float(act), 2),
                                    sur=None if pd.isna(sur) else round(float(sur), 1), rx=rx))
        except Exception:
            pass
    ev.sort(key=lambda e: (e["d"], -e["imp"]))
    results.sort(key=lambda r: r["d"], reverse=True)
    return ev, results[:12]

# ---------- 景氣循環 ----------
LIGHTS = [(38, "紅燈", "🔴", "景氣熱絡／接近高峰", "企業獲利與出口強勁，但股價往往已提前反映；留意升息、通膨與高檔震盪風險。歷史上紅燈後景氣常在數月內轉向。"),
          (32, "黃紅燈", "🟠", "景氣轉熱", "成長動能強，電子、鋼鐵、航運等景氣循環股通常表現較佳；需留意過熱訊號。"),
          (23, "綠燈", "🟢", "景氣穩定", "多數產業穩健成長，選股重點在獲利是否持續成長與評價是否合理。"),
          (17, "黃藍燈", "🟡", "景氣轉向低迷", "內需與出口放緩，防禦型族群（食品、電信、公用事業）相對抗跌；股市常提前反映，留意落底訊號。"),
          (0, "藍燈", "🔵", "景氣低迷", "基本面最弱，但歷史上股市常在藍燈前後築底；逆向布局需要耐心與風險控管。")]
GUIDE = [("復甦期", "景氣由藍／黃藍轉綠", "金融、營建、半導體等領先族群常先反彈"),
         ("擴張期", "綠燈～黃紅燈", "電子、機械、鋼鐵、航運等景氣循環股表現較強"),
         ("過熱期", "黃紅燈～紅燈", "原物料、能源、航運常見高點；留意升息與獲利見頂"),
         ("趨緩衰退期", "黃藍燈～藍燈", "公用事業、食品、電信、醫療等防禦族群相對抗跌")]

def get_ndc():
    try:
        url = "https://news.google.com/rss/search?q=" + urllib.parse.quote("景氣對策信號 國發會 綜合判斷分數 when:45d") + "&hl=zh-TW&gl=TW&ceid=TW:zh-Hant"
        import xml.etree.ElementTree as ET
        for it in ET.fromstring(requests.get(url, headers=UA, timeout=30).content).iter("item"):
            t = it.findtext("title") or ""
            m = re.search(r"(\d{2})\s*分", t)
            if "景氣" in t and m and 9 <= int(m.group(1)) <= 45:
                s = int(m.group(1)); L = next(x for x in LIGHTS if s >= x[0])
                return dict(score=s, light=L[1], emoji=L[2], stage=L[3], desc=L[4], title=t.rsplit(" - ", 1)[0],
                            d=email.utils.parsedate_to_datetime(it.findtext("pubDate")).astimezone(TZ).strftime("%m/%d"))
    except Exception as e:
        print("景氣燈號略過", e)
    return None

def build_cycle():
    try:
        d = yf.download(["^TWII", "^VIX", "^TNX"], period="2y", group_by="ticker", progress=False, threads=True, auto_adjust=False)
        c = d["^TWII"]["Close"].dropna(); last = c.iloc[-1]
        b240 = (last / c.rolling(240).mean().iloc[-1] - 1) * 100; b60 = (last / c.rolling(60).mean().iloc[-1] - 1) * 100
        rsi = float(_rsi(c).iloc[-1]); dd = (last / c.iloc[-250:].max() - 1) * 100
        vix = float(d["^VIX"]["Close"].dropna().iloc[-1]); tnx = d["^TNX"]["Close"].dropna()
        S, it = 0, []
        def add(n, v, s, txt):
            nonlocal S
            S += s; it.append(dict(n=n, v=v, s=txt))
        add("加權指數相對年線（240日）", f"{b240:+.1f}%", 2 if b240 > 20 else 1 if b240 > 10 else -2 if b240 < -20 else -1 if b240 < -10 else 0,
            "過熱" if b240 > 20 else "偏熱" if b240 > 10 else "冰點" if b240 < -20 else "偏冷" if b240 < -10 else "中性")
        add("加權指數相對季線（60日）", f"{b60:+.1f}%", 1 if b60 > 8 else -1 if b60 < -8 else 0, "偏熱" if b60 > 8 else "偏冷" if b60 < -8 else "中性")
        add("RSI(14)", f"{rsi:.0f}", 1 if rsi > 70 else -1 if rsi < 30 else 0, "超買" if rsi > 70 else "超賣" if rsi < 30 else "中性")
        add("距52週高點", f"{dd:.1f}%", 1 if dd > -3 else -1 if dd < -20 else 0, "接近高點" if dd > -3 else "明顯回檔" if dd < -20 else "一般")
        add("VIX 恐慌指數", f"{vix:.1f}", 1 if vix < 14 else -1 if vix > 25 else 0, "市場自滿" if vix < 14 else "恐慌" if vix > 25 else "正常")
        lab, emo = (("過熱區", "🔥") if S >= 4 else ("偏熱", "🌡️") if S >= 2 else ("中性", "⚖️") if S > -2 else ("偏冷", "🧊") if S > -4 else ("低檔／恐慌區", "❄️"))
        note = {"過熱區": "歷史上這類位置回檔風險較高，追價宜謹慎。", "偏熱": "多頭氣氛濃厚，但漲幅已大，留意獲利了結。",
                "中性": "沒有明顯過熱或過冷訊號。", "偏冷": "市場偏弱，可觀察是否出現止跌訊號。", "低檔／恐慌區": "市場情緒悲觀，歷史上常接近階段低點，但可能持續探底。"}[lab]
        return dict(score=S, label=lab, emoji=emo, note=note, items=it, tnx=round(float(tnx.iloc[-1]), 2), tnx_chg=round(float(tnx.iloc[-1] - tnx.iloc[-64]), 2) if len(tnx) > 64 else None)
    except Exception as e:
        print("市場溫度計算失敗", e); return None

def build(us):
    today = dt.datetime.now(TZ).date()
    ev, results = build_events(today, us)
    return dict(today=today.isoformat(), upd=dt.datetime.now(TZ).strftime("%m/%d %H:%M"), events=ev, results=results,
                cycle=dict(temp=build_cycle(), ndc=get_ndc(), guide=[dict(n=a, l=b, t=c) for a, b, c in GUIDE],
                           lights=[dict(min=m, light=l, emoji=e, stage=s, desc=t) for m, l, e, s, t in LIGHTS]))
