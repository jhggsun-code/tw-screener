"""三大法人買賣超（證交所官方資料，僅上市個股；欄位若變動會自動略過）"""
import re, datetime as dt, requests

H = {"User-Agent": "Mozilla/5.0 (personal research tool)"}

def num(x):
    m = re.search(r"-?\d+(?:\.\d+)?", str(x).replace(",", ""))
    return float(m.group()) if m else 0.0

def _get(url):
    try:
        return requests.get(url, headers=H, timeout=40).json()
    except Exception as e:
        print("法人資料失敗", url[-45:], e); return {}

def _idx(fields, *keys):
    for i, n in enumerate(fields):
        if all(k in n for k in keys):
            return i
    return None

def fetch_t86(day):
    """{代號: [外資, 投信, 三大法人合計]}，單位：張"""
    j = _get(f"https://www.twse.com.tw/rwd/zh/fund/T86?date={day:%Y%m%d}&selectType=ALLBUT0999&response=json")
    if j.get("stat") != "OK" or not j.get("data"):
        return None
    f = j.get("fields", [])
    fi, it, tt = _idx(f, "外陸資買賣超股數", "不含外資自營商"), _idx(f, "投信買賣超股數"), _idx(f, "三大法人買賣超股數")
    if fi is None:
        fi = _idx(f, "外資", "買賣超股數")
    if tt is None or it is None or fi is None:
        print("T86 欄位找不到", f[:6]); return None
    return {str(r[0]).strip(): [round(num(r[fi]) / 1000), round(num(r[it]) / 1000), round(num(r[tt]) / 1000)] for r in j["data"]}

def fetch_bfi(day):
    """全市場三大法人買賣差額（億元）：{外資, 投信, 自營商, 合計}"""
    j = _get(f"https://www.twse.com.tw/rwd/zh/fund/BFI82U?dayDate={day:%Y%m%d}&type=day&response=json")
    if j.get("stat") != "OK" or not j.get("data"):
        return None
    out = {"外資": 0.0, "投信": 0.0, "自營商": 0.0, "合計": 0.0}
    for r in j["data"]:
        name, diff = str(r[0]), num(r[-1]) / 1e8
        if "合計" in name:
            out["合計"] = diff
        elif "外資" in name and "自營商" not in name.replace("外資自營商", "") or name.startswith("外資及陸資"):
            out["外資"] += diff
        elif "投信" in name:
            out["投信"] += diff
        elif "自營商" in name:
            out["自營商"] += diff
    return {k: round(v, 1) for k, v in out.items()}

def get_chips(ref=None):
    """往前找最近一個有資料的交易日（最多 7 天）；回傳 dict(date, mkt, stocks) 或 None"""
    day = ref or dt.date.today()
    for _ in range(7):
        if day.weekday() < 5:
            st = fetch_t86(day)
            if st:
                return dict(date=str(day), mkt=fetch_bfi(day), stocks=st)
        day -= dt.timedelta(days=1)
    return None

def rank_lists(chips, allst, n=8):
    """外資買超／賣超前幾名（張），附名稱與漲跌"""
    rows = []
    for c, v in (chips or {}).get("stocks", {}).items():
        x = allst.get(c)
        if x and not x.get("kind") and v[0]:
            rows.append(dict(code=c, n=x["name"], fi=v[0], it=v[1], tt=v[2], c=x["close"], p=x["pct"]))
    rows.sort(key=lambda r: -r["fi"])
    return rows[:n], sorted(rows, key=lambda r: r["fi"])[:n]
