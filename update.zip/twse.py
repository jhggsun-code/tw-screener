"""證交所／櫃買官方開放資料：當日收盤行情與加權指數
Yahoo 常在收盤後數小時才更新最新交易日，這裡用官方資料補齊，讓畫面盡快顯示「當日收盤」。"""
import re, time, datetime as dt
import requests

TZ = dt.timezone(dt.timedelta(hours=8))
URL_TWSE = "https://openapi.twse.com.tw/v1/exchangeReport/STOCK_DAY_ALL"
URL_TPEX = "https://www.tpex.org.tw/openapi/v1/tpex_mainboard_daily_close_quotes"
URL_TAIEX = "https://openapi.twse.com.tw/v1/exchangeReport/FMTQIK"

def today():
    return dt.datetime.now(TZ).date()

def num(x):
    m = re.search(r"-?\d+(?:\.\d+)?", str(x).replace(",", "")) if x not in (None, "", "--", "---") else None
    return float(m.group()) if m else None

def to_date(s):
    """民國 1141029／114/10/29 或西元 20251029／2025/10/29 → date"""
    s = re.sub(r"\D", "", str(s or ""))
    try:
        if len(s) == 7:
            return dt.date(int(s[:3]) + 1911, int(s[3:5]), int(s[5:7]))
        if len(s) == 8:
            return dt.date(int(s[:4]), int(s[4:6]), int(s[6:8]))
    except Exception:
        pass
    return None

def rows(url):
    try:
        r = requests.get(url, timeout=40, headers={"User-Agent": "Mozilla/5.0 (personal research tool)"})
        d = r.json()
        return d if isinstance(d, list) else []
    except Exception as e:
        print("官方資料失敗", url[-30:], e); return []

def pick(x, keys):
    for k in keys:
        if x.get(k) not in (None, "", "--"):
            return x[k]

def official_bars():
    """{代號: dict(d=日期, o,h,l,c, v=成交股數, chg=漲跌)}，含上市與上櫃；只收有成交的標的"""
    out = {}
    for x in rows(URL_TWSE):
        c, code = num(x.get("ClosingPrice")), x.get("Code")
        v = num(x.get("TradeVolume")) or 0
        if code and c and v > 0:
            out[code] = dict(d=to_date(x.get("Date")), o=num(x.get("OpeningPrice")), h=num(x.get("HighestPrice")),
                             l=num(x.get("LowestPrice")), c=c, v=v, chg=num(x.get("Change")) or 0.0)
    for x in rows(URL_TPEX):
        code = pick(x, ["SecuritiesCompanyCode", "Code"])
        c, v = num(pick(x, ["Close", "ClosingPrice"])), num(pick(x, ["TradingShares", "TradeVolume"])) or 0
        if code and c and v > 0:
            out[code] = dict(d=to_date(pick(x, ["Date", "TradeDate"])), o=num(x.get("Open")), h=num(x.get("High")),
                             l=num(x.get("Low")), c=c, v=v, chg=num(x.get("Change")) or 0.0)
    return out

def pct(b):
    prev = b["c"] - b["chg"]
    return round(b["chg"] / prev * 100, 2) if prev else 0.0

def official_twii():
    """加權指數最新一個交易日：dict(d, c, chg)；抓不到回傳 None"""
    r = rows(URL_TAIEX)
    for x in reversed(r):
        c, d = num(pick(x, ["TAIEX", "發行量加權股價指數"])), to_date(pick(x, ["Date", "日期"]))
        if c and d:
            return dict(d=d, c=c, chg=num(pick(x, ["Change", "漲跌點數"])) or 0.0)
    return None

def latest_date(bars):
    ds = [b["d"] for b in bars.values() if b.get("d")]
    return max(ds) if ds else None

def wait_official(max_min=12):
    """排程的收盤後分析：若官方當日資料尚未公布，最多等 12 分鐘（每 4 分鐘查一次）。
    只有環境變數 WAIT_OFFICIAL=1（排程執行）才會等；手動執行、休市日、抓不到日期時都不等。"""
    import os
    if os.getenv("WAIT_OFFICIAL") != "1":
        return
    n = dt.datetime.now(TZ)
    if n.weekday() > 4 or not (13 * 60 + 50 <= n.hour * 60 + n.minute < 21 * 60):
        return
    for i in range(max_min // 4):
        d = latest_date(official_bars())
        if d is None:
            print("無法取得官方資料日期，不等待"); return
        if d >= n.date():
            print("官方當日資料已公布", d); return
        print(f"官方當日資料尚未公布（最新 {d}），4 分鐘後再查（{i + 1}/{max_min // 4}）")
        time.sleep(240)
    print("等待逾時，改用目前可取得的資料繼續")
