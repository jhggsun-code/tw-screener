"""台股盤中近即時報價（證交所「基本市況報導」MIS，約每 30 秒）→ 推送到 live 分支的 live.json
由 GitHub Actions 在開盤前啟動，執行到收盤後自動結束。MIS 連不上時，加權指數退回 Yahoo（可能延遲）。"""
import os, sys, json, time, subprocess, datetime as dt
import requests

TZ = dt.timezone(dt.timedelta(hours=8))
MIS = "https://mis.twse.com.tw/stock/api/getStockInfo.jsp"
H = {"User-Agent": "Mozilla/5.0 (personal research tool)", "Referer": "https://mis.twse.com.tw/stock/index.jsp"}
OUT = "live_out"
CYCLE, END_MIN = 30, 13 * 60 + 35          # 每 30 秒一輪；台灣時間 13:35 結束
N_STOCKS = 150                             # 以成交值排名前 150 檔個股

def now():
    return dt.datetime.now(TZ)

def pick_codes():
    try:
        s = json.load(open("docs/stocks.json", encoding="utf-8"))["s"]
        top = sorted(s.items(), key=lambda kv: -(kv[1].get("tn") or 0))[:N_STOCKS]
        return [("otc_" if x.get("x") == "上櫃" else "tse_") + c + ".tw" for c, x in top]
    except Exception as e:
        print("讀取 stocks.json 失敗", e); return []

def fetch(sess, chans):
    r = sess.get(MIS, params={"ex_ch": "|".join(chans), "json": "1", "delay": "0", "_": int(time.time() * 1000)}, timeout=15)
    return r.json().get("msgArray", [])

def num(x):
    try:
        return float(x)
    except Exception:
        return None

def parse(arr, out):
    for m in arr:
        p, y, c = num(m.get("z")), num(m.get("y")), m.get("c", "")
        if p is None or not y:
            continue
        v = [round(p, 2), round((p / y - 1) * 100, 2), round(p - y, 2)]
        if c == "t00":
            out["ix"]["^TWII"] = v
        elif c == "o00":
            out["ix"]["^TWOII"] = v
        else:
            out["tw"][c] = v

def yahoo_twii(out):
    try:
        import yfinance as yf
        d = yf.download("^TWII", period="5d", interval="1m", progress=False, auto_adjust=False)["Close"]
        c = (d.iloc[:, 0] if hasattr(d, "columns") else d).dropna()
        dd = yf.download("^TWII", period="5d", progress=False, auto_adjust=False)["Close"]
        dd = (dd.iloc[:, 0] if hasattr(dd, "columns") else dd).dropna()
        last, prev = float(c.iloc[-1]), float(dd.iloc[-2] if str(dd.index[-1].date()) == str(c.index[-1].date()) else dd.iloc[-1])
        out["ix"]["^TWII"] = [round(last, 2), round((last / prev - 1) * 100, 2), round(last - prev, 2)]
        out["src"] = "yahoo"
    except Exception as e:
        print("Yahoo 備援失敗", e)

def git(*a, cwd=OUT):
    return subprocess.run(["git", *a], cwd=cwd, capture_output=True, text=True)

def push(first):
    if first:
        git("init", "-q", "-b", "live"); git("config", "user.name", "bot"); git("config", "user.email", "bot@users.noreply.github.com")
        repo, tok = os.getenv("GITHUB_REPOSITORY", ""), os.getenv("GH_TOKEN", "")
        git("remote", "add", "origin", f"https://x-access-token:{tok}@github.com/{repo}.git")
    git("add", "live.json")
    git("commit", "-q", "-m", "live", *([] if first else ["--amend"]))
    r = git("push", "-f", "-q", "origin", "live")
    if r.returncode:
        print("push 失敗", r.stderr[:200])

def main():
    os.makedirs(OUT, exist_ok=True)
    sess = requests.Session(); sess.headers.update(H)
    try:
        sess.get("https://mis.twse.com.tw/stock/index.jsp", timeout=15)
    except Exception:
        pass
    chans = pick_codes()
    batches = [chans[i:i + 40] for i in range(0, len(chans), 40)]
    first, fails, today = True, 0, now().strftime("%Y%m%d")
    while True:
        t = now(); mins = t.hour * 60 + t.minute
        if mins >= END_MIN:
            print("收盤，結束"); break
        t0 = time.time(); out = {"t": int(t0), "upd": t.strftime("%H:%M:%S"), "src": "twse", "ix": {}, "tw": {}}
        try:
            arr = fetch(sess, ["tse_t00.tw", "otc_o00.tw"]); parse(arr, out)
            if arr and mins >= 9 * 60 + 10 and all(m.get("d") not in (None, today) for m in arr if m.get("c") == "t00"):
                print("今日休市，結束"); break
            for b in batches:
                time.sleep(2); parse(fetch(sess, b), out)
        except Exception as e:
            print("MIS 失敗", e)
        if "^TWII" not in out["ix"]:
            fails += 1; yahoo_twii(out)
        else:
            fails = 0
        if out["ix"] or out["tw"]:
            json.dump(out, open(f"{OUT}/live.json", "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))
            push(first); first = False
            print(out["upd"], out["src"], "指數", out["ix"].get("^TWII"), "個股", len(out["tw"]))
        if mins < 8 * 60 + 58:
            time.sleep(60); continue
        time.sleep(max(5, CYCLE - (time.time() - t0)))

if __name__ == "__main__":
    main()
