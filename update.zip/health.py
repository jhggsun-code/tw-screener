"""資料健康檢查：每次完整分析後檢查各資料來源是否正常，結果寫入 health.json 並在 App 顯示"""
import os, json, datetime as dt

def item(n, s, d):
    return dict(n=n, s=s, d=d)

def build(date, allst, bars_n, bars_date, mk, nw, us, en, ev, flow, chips, ymd_today):
    L = []
    n = len(allst)
    L.append(item("台股個股與 ETF 資料", "ok" if n >= 1500 else "warn" if n >= 800 else "bad", f"{n} 檔，資料日 {date}"))
    if bars_n:
        same = bars_date and str(bars_date) == str(date)
        L.append(item("官方收盤資料（證交所／櫃買）", "ok" if same else "warn", f"{bars_n} 檔，日期 {bars_date}" + ("" if same else "（與資料日不同：官方尚未公布或 Yahoo 領先）")))
    else:
        L.append(item("官方收盤資料（證交所／櫃買）", "warn", "沒有取得，改用 Yahoo 資料（可能晚一天）"))
    tw = next((x for x in mk.get("items", []) if x.get("sym") == "^TWII"), None)
    L.append(item("加權指數", "ok" if tw else "bad", f"{tw['c']:,}，日期 {tw['d']}" if tw else "沒有取得"))
    tx = next((x for x in mk.get("items", []) if x.get("sym") == "TXF"), None)
    L.append(item("台指期（近月連續合約）", "ok" if tx else "warn", f"{tx['c']:,}，日期 {tx['d']}" if tx else "沒有取得（期交所資料暫時抓不到，不影響其他功能）"))
    shown = [x for x in mk.get("items", []) if x.get("show")]
    L.append(item("美股／亞股指數", "ok" if len(shown) >= 6 else "warn" if shown else "bad", f"{len(shown)} / 6 個"))
    ui = len(us.get("items", []))
    L.append(item("美股龍頭個股", "ok" if ui >= 50 else "warn" if ui else "bad", f"{ui} 檔"))
    L.append(item("台灣新聞", "ok" if len(nw.get("items", [])) >= 5 else "warn", f"{len(nw.get('items', []))} 則（{'AI 分析' if nw.get('mode') == 'ai' else '規則式'}）"))
    L.append(item("國際英文新聞", "ok" if len(en.get("items", [])) >= 5 else "warn", f"{len(en.get('items', []))} 則（{'含中文翻譯' if en.get('mode') == 'ai' else '僅原文，未設定 AI 金鑰'}）"))
    L.append(item("行事曆", "ok" if ev.get("events") else "warn", f"{len(ev.get('events', []))} 筆事件"))
    L.append(item("景氣燈號", "ok" if mk.get("ndc") else "warn", (f"{mk['ndc'].get('light')}（{mk['ndc'].get('score')} 分）" if mk.get("ndc") else "抓不到，僅顯示加權指數位置推估")))
    st = [x for x in allst.values() if not x.get("kind")]
    pe = sum(1 for x in st if x.get("pe") is not None)
    L.append(item("估值與產業資料", "ok" if st and pe / len(st) > 0.5 else "warn", f"{pe} / {len(st)} 檔有本益比"))
    L.append(item("資金流向", "ok" if flow else "warn", "已計算" if flow else "未產生（成交資料不足）"))
    L.append(item("三大法人籌碼", "ok" if chips else "warn", f"資料日 {chips['date']}" if chips else "沒有取得（證交所介面可能改版）"))
    try:
        b = json.load(open("docs/backtest.json", encoding="utf-8")); age = (dt.date.fromisoformat(ymd_today) - dt.date.fromisoformat(b["gen"])).days
        L.append(item("訊號回測", "ok" if age <= 14 else "warn", f"{b['gen']} 產生（{age} 天前）"))
    except Exception:
        L.append(item("訊號回測", "warn", "尚未產生（到 Actions 執行 backtest）"))
    return dict(gen=dt.datetime.now().strftime("%m/%d %H:%M"), items=L, bad=sum(x["s"] == "bad" for x in L), warn=sum(x["s"] == "warn" for x in L))

def alert_text(h):
    bad = [x for x in h["items"] if x["s"] == "bad"]
    return "🚨 台股選股 App 資料異常\n" + "\n".join(f"• {x['n']}：{x['d']}" for x in bad) + "\n請到 GitHub Actions 查看日誌。" if bad else ""
