"""App 圖示產生器
預設：藍青漸層底＋K 線圖示。想換成自己的圖：在專案最外層上傳一張 icon.png（正方形最佳，建議 512×512 以上），
下次執行 daily-screener 就會自動改用它，並產生手機需要的各種尺寸。"""
import os, sys, subprocess

def _pil():
    try:
        from PIL import Image, ImageDraw
        return Image, ImageDraw
    except Exception:
        try:
            subprocess.run([sys.executable, "-m", "pip", "install", "-q", "pillow"], check=True, timeout=180)
            from PIL import Image, ImageDraw
            return Image, ImageDraw
        except Exception as e:
            print("Pillow 不可用，使用內建簡易圖示", e); return None

def _grad(Image, size, c1=(59, 111, 224), c2=(34, 182, 201)):
    im = Image.new("RGB", (size, size), c1)
    px = im.load()
    for y in range(size):
        for x in range(size):
            t = (x + y) / (2 * size - 2)
            px[x, y] = tuple(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(3))
    return im

def _default(Image, ImageDraw, size):
    S = 4 if size <= 512 else 2                       # 超取樣讓邊緣更平滑
    big = size * S
    im = _grad(Image, 256).resize((big, big), Image.BICUBIC).convert("RGBA")
    d = ImageDraw.Draw(im, "RGBA")
    u = lambda v: int(v * big)
    candles = [(0.30, 0.46, 0.74, 0.54, 0.68, (255, 255, 255, 235)),
               (0.50, 0.34, 0.68, 0.42, 0.60, (255, 255, 255, 235)),
               (0.70, 0.20, 0.60, 0.27, 0.50, (255, 93, 93, 255))]      # 台股習慣：紅＝漲
    d.line([(u(0.22), u(0.70)), (u(0.78), u(0.22))], fill=(255, 255, 255, 70), width=u(0.02))
    for cx, w0, w1, b0, b1, col in candles:
        d.rounded_rectangle([u(cx - 0.008), u(w0), u(cx + 0.008), u(w1)], radius=u(0.008), fill=col)
        d.rounded_rectangle([u(cx - 0.065), u(b0), u(cx + 0.065), u(b1)], radius=u(0.025), fill=col)
    return im.resize((size, size), Image.LANCZOS).convert("RGB")

def _custom(Image, src, size, maskable=False):
    w, h = src.size; m = min(w, h)
    sq = src.crop(((w - m) // 2, (h - m) // 2, (w - m) // 2 + m, (h - m) // 2 + m)).convert("RGBA")
    if not maskable:
        bg = Image.new("RGBA", sq.size, (255, 255, 255, 255)); bg.alpha_composite(sq)
        return bg.convert("RGB").resize((size, size), Image.LANCZOS)
    edge = sq.convert("RGB").getpixel((2, 2))                     # 用圖片邊角顏色當底，內容縮到安全範圍
    canvas = Image.new("RGB", (size, size), edge)
    inner = int(size * 0.78)
    pic = sq.resize((inner, inner), Image.LANCZOS)
    canvas.paste(pic, ((size - inner) // 2,) * 2, pic)
    return canvas

def make_icons(out="docs", custom_paths=("icon.png",)):
    """回傳 True 表示已用 Pillow 產生；False 表示請改用內建簡易圖示"""
    mods = _pil()
    if not mods:
        return False
    Image, ImageDraw = mods
    os.makedirs(out, exist_ok=True)
    src = None
    for p in custom_paths:
        if os.path.exists(p):
            try:
                src = Image.open(p); src.load(); print("使用自訂圖示", p, src.size); break
            except Exception as e:
                print("自訂圖示讀取失敗，改用預設", e)
    for name, size, mask in (("icon-192.png", 192, False), ("icon-512.png", 512, False),
                             ("icon-maskable-512.png", 512, True), ("apple-touch-icon.png", 180, False)):
        im = _custom(Image, src, size, mask) if src is not None else _default(Image, ImageDraw, size)
        im.save(os.path.join(out, name), optimize=True)
    return True
