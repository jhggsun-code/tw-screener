"""美股與亞洲指標、新聞（重點10則＋利弊分析）、通知（由 screener.py 匯入）"""
import os, re, json, email.utils, urllib.parse, datetime as dt
import xml.etree.ElementTree as ET
from collections import Counter
import numpy as np, pandas as pd, requests, yfinance as yf

TZ = dt.timezone(dt.timedelta(hours=8))
UA = {"User-Agent": "Mozilla/5.0 (personal research tool)"}

def claude_json(prompt, max_tokens=4000):
    """呼叫 Claude API 並解析回傳的 JSON；沒設定 ANTHROPIC_API_KEY 或失敗時回傳 None"""
    key = os.getenv("ANTHROPIC_API_KEY")
    if not key:
        return None
    try:
        r = requests.post("https://api.anthropic.com/v1/messages", timeout=180,
                          headers={"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
                          json={"model": os.getenv("ANTHROPIC_MODEL", "claude-sonnet-5-5"), "max_tokens": max_tokens,
                                "messages": [{"role": "user", "content": prompt}]})
        text = "".join(b.get("text", "") for b in r.json()["content"] if b.get("type") == "text")
        return json.loads(text[text.index("{"): text.rindex("}") + 1])
    except Exception as e:
        print("AI 呼叫失敗", e); return None

# ---------- 指標（美股、韓、日、台股加權）----------
# (代號, 名稱, 圖示, 是否顯示在美股頁最上方, 說明)
MARKETS = [
    ("^DJI", "道瓊工業", "🏭", 1, "追蹤 30 檔美國大型藍籌公司的「價格加權」指數，成分股偏傳統產業、金融、消費與工業；股價越高的成分股影響越大。是歷史最悠久的美股指標，反映美國大型傳統企業的景氣。"),
    ("^GSPC", "S&P 500", "🇺🇸", 1, "追蹤美國 500 家大型上市公司（約涵蓋美股總市值的 80%），以市值加權，是最廣泛使用的美股大盤基準。蘋果、微軟、輝達等科技巨頭權重很高，可代表美國整體股市與經濟。"),
    ("^SOX", "費城半導體", "🔌", 1, "追蹤 30 檔在美國上市的大型半導體公司（設計、製造、設備），包含輝達、博通、超微、美光、台積電 ADR 等。是台灣電子與半導體股最重要的外部風向球，費半大漲大跌常帶動台股隔日電子股。"),
    ("^IXIC", "那斯達克", "💻", 1, "涵蓋那斯達克交易所全部上市股票（3,000 檔以上），科技與成長股占比很高，對利率變化敏感。反映市場對科技、AI 與成長股的風險偏好。"),
    ("^KS11", "韓國 KOSPI", "🇰🇷", 1, "追蹤南韓交易所上市的全部普通股，三星電子與 SK 海力士權重很大，與全球記憶體、半導體循環高度連動。常被當作亞洲科技與半導體同業的參考。"),
    ("^N225", "日經 225", "🇯🇵", 1, "追蹤東京證交所 225 檔代表性大型股（價格加權），出口與製造業占比高，受日圓匯率影響很大（日圓貶值通常有利出口股）。是亞洲最主要的股市指標之一。"),
    ("TSM", "台積電 ADR", "🇹🇼", 0, "台積電在美國上市的存託憑證，1 張 ADR 約等於 5 股台積電普通股，常用來預判台積電隔日開盤方向。"),
    ("^VIX", "VIX 恐慌指數", "😨", 0, "由 S&P 500 選擇權價格推算出的預期波動率，數字越高代表市場越恐慌。"),
    ("^TNX", "美10年期殖利率", "📊", 0, "美國 10 年期公債殖利率，是全球資金成本的基準，上升通常壓抑成長股估值。"),
    ("TWD=X", "美元/台幣", "💱", 0, "1 美元兌換多少新台幣，數字上升代表新台幣貶值。"),
    ("^TWII", "台股加權", "📈", 0, "追蹤台灣證券交易所全部上市普通股的市值加權指數，台積電權重約占三成以上，是台股大盤的代表。指數漲跌主要受電子權值股、外資買賣超與美股影響。"),
]

def _rsi(c, n=14):
    d = c.diff()
    up = d.clip(lower=0).ewm(alpha=1/n, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1/n, adjust=False).mean()
    return 100 - 100 / (1 + up / dn.replace(0, np.nan))

def index_eval(c):
    """指數的技術面解讀：6項檢查、趨勢標籤、重點說明"""
    n = len(c)
    if n < 30:
        return {}
    f = lambda x, k=2: round(float(x), k)
    last = c.iloc[-1]
    ma20, ma60 = c.rolling(20).mean(), c.rolling(60).mean()
    macd = c.ewm(span=12, adjust=False).mean() - c.ewm(span=26, adjust=False).mean()
    hist = macd - macd.ewm(span=9, adjust=False).mean()
    r = float(_rsi(c).iloc[-1]); h52, l52 = c.iloc[-250:].max(), c.iloc[-250:].min()
    has60 = n >= 60 and ma60.iloc[-1] == ma60.iloc[-1]
    dd = (last / h52 - 1) * 100
    ck = "".join("1" if x else "0" for x in (last > ma20.iloc[-1], has60 and last > ma60.iloc[-1],
                                              ma20.iloc[-1] > ma20.iloc[-6], hist.iloc[-1] > 0, 50 <= r <= 75, dd > -10))
    if has60 and last > ma20.iloc[-1] > ma60.iloc[-1]:
        tr = "多頭排列"
    elif has60 and last < ma20.iloc[-1] < ma60.iloc[-1]:
        tr = "空頭排列"
    else:
        tr = "盤整震盪"
    why = []
    if has60:
        why.append(f"收盤 {f(last)}，月線 {f(ma20.iloc[-1])}、季線 {f(ma60.iloc[-1])}：" + {"多頭排列": "站上月線與季線，中期趨勢向上", "空頭排列": "低於月線與季線，中期趨勢偏弱", "盤整震盪": "與均線糾結，方向尚未明確"}[tr])
    why.append("RSI %.0f：" % r + ("70 以上，短線偏熱，留意獲利了結或回檔" if r >= 70 else "30 以下，屬超賣區，留意反彈或持續探底" if r <= 30 else "位於 30～70 中性區間，無極端訊號"))
    why.append(f"距 52 週高點 {dd:.1f}%（高 {f(h52)}、低 {f(l52)}）")
    why.append("MACD 柱狀體為" + ("正，動能偏多" if hist.iloc[-1] > 0 else "負，動能偏空") + ("，且在擴大" if abs(hist.iloc[-1]) > abs(hist.iloc[-2]) else "，且在收斂"))
    g = lambda k: f((last / c.iloc[-k - 1] - 1) * 100) if n > k else None
    return dict(ck=ck, tr=tr, why=why, h=f(h52), l=f(l52), g5=g(5), g20=g(20), rsi=f(r, 1), a=f(ma20.iloc[-1]),
                z=f(ma60.iloc[-1]) if has60 else None)

def get_market():
    items = []
    try:
        d = yf.download([m[0] for m in MARKETS], period="1y", group_by="ticker", progress=False, threads=True, auto_adjust=False)
    except Exception as e:
        print("指標資料失敗", e); return dict(items=[], hint=[])
    for sym, name, emo, show, desc in MARKETS:
        try:
            c = d[sym]["Close"].dropna(); off = None
            if sym == "^TWII":
                try:
                    import twse, pandas as pd
                    o = off = twse.official_twii()
                    if o:
                        ts = pd.Timestamp(o["d"])
                        ts = ts.tz_localize(c.index.tz) if getattr(c.index, "tz", None) is not None else ts
                        if o["d"] > c.index[-1].date():
                            c = pd.concat([c, pd.Series([o["c"]], index=[ts])])
                        elif o["d"] == c.index[-1].date():
                            c.iloc[-1] = o["c"]
                except Exception as e:
                    print("加權指數官方補值略過", e)
            items.append(dict(sym=sym, name=name, e=emo, show=show, desc=desc, c=round(float(c.iloc[-1]), 2),
                              p=round(float((c.iloc[-1] / c.iloc[-2] - 1) * 100), 2), ch=round(float(c.iloc[-1] - c.iloc[-2]), 3),
                              d=str(c.index[-1].date()), sp=[round(float(x), 2) for x in c.iloc[-20:]],
                              hist=[round(float(x), 2) for x in c.iloc[-100:]], dates=[x.strftime("%m-%d") for x in c.index[-100:]],
                              ev=index_eval(c)))
            if sym == "^TWII" and off and off["d"] == c.index[-1].date() and off["c"] != off["chg"]:
                items[-1].update(ch=round(off["chg"], 2), p=round(off["chg"] / (off["c"] - off["chg"]) * 100, 2))
        except Exception:
            continue
    try:
        import taifex
        tx = taifex.market_item(index_eval, next((x for x in items if x["sym"] == "^TWII"), None))
        if tx:
            items.append(tx)
    except Exception as ex:
        print("台指期略過", ex)
    g = {x["sym"]: x for x in items}
    hint = []
    sox, ndx, tsm, vix = g.get("^SOX"), g.get("^IXIC"), g.get("TSM"), g.get("^VIX")
    if sox and ndx:
        if sox["p"] >= 1.5 and ndx["p"] >= 1:
            hint.append("🔥 美股科技強勢，電子／半導體股開盤情緒偏多（參考）")
        elif sox["p"] <= -1.5 and ndx["p"] <= -1:
            hint.append("🧊 美股科技走弱，電子／半導體股開盤壓力偏大（參考）")
        else:
            hint.append("美股科技變動不大，台股以自身走勢為主")
    if tsm:
        hint.append(f"台積電 ADR {tsm['p']:+.1f}%，可參考今日台積電開盤方向")
    if vix and (vix["p"] >= 10 or vix["c"] >= 25):
        hint.append(f"😨 VIX {vix['c']}，避險情緒升高，操作宜保守")
    return dict(items=items, hint=hint)

def mk_line(mk):
    g = {x["sym"]: x for x in mk["items"]}
    names = [("^SOX", "費半"), ("^IXIC", "那指"), ("^DJI", "道瓊")]
    return "🌎 美股：" + "　".join(f"{n} {g[s]['p']:+.2f}%" for s, n in names if s in g) if g else ""

# ---------- 新聞分類 ----------
CATS = ["央行利率", "通膨經濟數據", "貿易關稅", "AI與半導體", "科技公司", "公司財報", "能源原物料", "地緣政治", "匯率債市", "市場動態", "其他"]
CAT_ZH = [("央行利率", r"聯準會|Fed|升息|降息|央行|利率|鮑爾|縮表|寬鬆|鷹派|鴿派"),
          ("通膨經濟數據", r"通膨|CPI|PCE|非農|就業|GDP|失業|景氣|衰退|PMI|零售銷售|經濟成長"),
          ("貿易關稅", r"關稅|貿易戰|出口管制|禁令|制裁|晶片法|貿易"),
          ("AI與半導體", r"輝達|AI|半導體|晶圓|台積電|HBM|CoWoS|伺服器|晶片|美光"),
          ("科技公司", r"蘋果|微軟|谷歌|Google|亞馬遜|Meta|特斯拉|OpenAI|英特爾|Intel|SpaceX"),
          ("公司財報", r"財報|營收|獲利|EPS|法說|財測|股息|配息"),
          ("能源原物料", r"原油|油價|天然氣|黃金|銅價|OPEC|煤|鋼"),
          ("地緣政治", r"中東|烏克蘭|俄羅斯|台海|戰爭|衝突|飛彈|以色列|伊朗|北韓|選舉|川普"),
          ("匯率債市", r"新台幣|美元|匯率|殖利率|公債|日圓|美債|人民幣"),
          ("市場動態", r"台股|美股|外資|大盤|股市|指數|ETF|漲停|跌停")]

def classify(title, rules=None, default="其他"):
    for name, pat in (rules or CAT_ZH):
        if re.search(pat, title, re.I):
            return name
    return default

# ---------- 重要程度排序 ----------
CAT_W = {"央行利率": 5, "通膨經濟數據": 5, "貿易關稅": 4, "AI與半導體": 4, "地緣政治": 4, "科技公司": 3, "公司財報": 3,
         "能源原物料": 3, "匯率債市": 3, "市場動態": 2, "其他": 1}
BOOST = re.compile(r"聯準會|Fed\b|降息|升息|關稅|輝達|台積電|崩|暴跌|大漲|創高|新高|戰爭|制裁|財報|CPI|非農|Nvidia|Powell|tariff|crash|record|plunge|surge|rate cut|rate hike", re.I)

def _bg(s):
    s = re.sub(r"\W", "", s.lower()); return {s[i:i + 2] for i in range(len(s) - 1)}

def score_items(items):
    """依分類權重、關鍵字、相似報導數量（越多媒體報導越重要）、新舊程度打分，回傳由高到低排序的清單，並加上 imp(1~5)"""
    now = dt.datetime.now(dt.timezone.utc).timestamp()
    bg = [_bg(x["title"]) for x in items]
    for i, x in enumerate(items):
        dup = sum(1 for j in range(len(items)) if j != i and bg[i] and bg[j] and len(bg[i] & bg[j]) / len(bg[i] | bg[j]) >= .3)
        hrs = max(0, (now - x.get("ts", now)) / 3600)
        x["score"] = CAT_W.get(x.get("cat", "其他"), 1) * 2 + (3 if BOOST.search(x["title"]) else 0) + min(dup, 5) * 1.5 + max(0, 6 - hrs / 4) * .5 \
            + (1 if x.get("dir", "中性") != "中性" else 0)
    items.sort(key=lambda x: -x["score"])
    mx = items[0]["score"] if items else 1
    for x in items:
        r = x["score"] / mx
        x["imp"] = 5 if r >= .85 else 4 if r >= .7 else 3 if r >= .55 else 2 if r >= .4 else 1
    return items

def procon(d, why=""):
    """規則式的「利／弊」說明"""
    if d == "偏多":
        return (why or "整體風險偏好改善，有利股市", "市場可能已提前反映，短線追價風險較高；若後續數據或政策不如預期，利多可能回吐")
    if d == "偏空":
        return ("跌深後若消息緩和，可能出現反彈；防禦型族群（電信、食品、公用事業）通常相對抗跌", why or "風險偏好下降，市場波動可能放大")
    return ("目前對大盤影響不明顯，不必過度反應", "個別族群可能出現短線波動，需觀察後續發展")

# ---------- 台灣新聞 ----------
NEWS_Q = [("總經／央行", "聯準會 OR 升息 OR 降息 OR 通膨 OR 非農 OR 央行"),
          ("貿易／政策", "關稅 OR 出口管制 OR 貿易戰 OR 制裁 OR 晶片法"),
          ("科技／AI", "輝達 OR 台積電 OR AI伺服器 OR 半導體 OR 蘋果"),
          ("能源／地緣", "原油 OR 油價 OR 中東 OR 烏克蘭 OR 台海"),
          ("台股／匯市", "台股 OR 新台幣 OR 外資 OR 美股")]

def get_news():
    now, seen, items = dt.datetime.now(dt.timezone.utc), set(), []
    for cat, q in NEWS_Q:
        url = ("https://news.google.com/rss/search?q=" + urllib.parse.quote(q + " when:1d") + "&hl=zh-TW&gl=TW&ceid=TW:zh-Hant")
        try:
            root = ET.fromstring(requests.get(url, headers=UA, timeout=30).content)
        except Exception as e:
            print("新聞失敗", cat, e); continue
        n = 0
        for it in root.iter("item"):
            title, link = (it.findtext("title") or "").strip(), it.findtext("link") or ""
            src = it.findtext("source") or ""
            if src and title.endswith(" - " + src):
                title = title[:-len(src) - 3]
            try:
                t = email.utils.parsedate_to_datetime(it.findtext("pubDate"))
            except Exception:
                continue
            key = re.sub(r"\W", "", title)[:16]
            if not title or key in seen or (now - t).total_seconds() > 36 * 3600:
                continue
            seen.add(key); n += 1
            items.append(dict(cat=cat, title=title, link=link, src=src, ts=t.timestamp(), t=t.astimezone(TZ).strftime("%m/%d %H:%M")))
            if n >= 9:
                break
    return items

UP_W = re.compile(r"大漲|飆漲|創高|新高|亮眼|超預期|優於預期|上調|擴產|大單|利多|反彈|受惠|成長")
DN_W = re.compile(r"大跌|重挫|暴跌|衰退|下修|砍單|減產|不如預期|低於預期|裁員|利空|恐慌|危機|示警|下滑")
FLIP = re.compile(r"取消|暫緩|延後|放寬|解除|緩和|停火|休戰|降溫|落空|不降息|不升息|降低")
RULES = [  # (關鍵字, 固定方向或None, 可能影響族群, 傳導邏輯)
    (r"降息|寬鬆|降準|買債", "偏多", "成長股／科技股、營建", "資金成本下降，有利股市估值"),
    (r"升息|鷹派|縮表|殖利率(上升|攀升|走高|飆)|通膨(升溫|惡化|超預期)", "偏空", "成長股／科技股（銀行等金融股相對受惠）", "資金成本上升，壓抑股市估值"),
    (r"關稅|貿易戰|出口管制|禁令|制裁", "偏空", "電子／半導體／航運／傳產出口", "供應鏈成本與訂單不確定性上升"),
    (r"(油價|原油).{0,6}(上漲|飆|攀升|走高|大漲)", "偏空", "航空／運輸／塑化下游（石油相關族群相對受惠）", "成本上升、通膨壓力增加"),
    (r"(油價|原油).{0,6}(下跌|重挫|走低|大跌)", "偏多", "航空／運輸／塑化下游", "成本下降、通膨壓力減輕"),
    (r"中東|烏克蘭|俄羅斯|台海|戰爭|衝突|飛彈", "偏空", "航運、油價敏感族群；避險情緒升高", "地緣風險升高，通常拉大市場波動"),
    (r"輝達|AI|伺服器|資料中心|HBM|CoWoS|晶圓代工|半導體", None, "AI 供應鏈／半導體", "AI 與半導體消息會帶動相關供應鏈情緒"),
    (r"新台幣", None, "出口電子（升值不利）、壽險（升值有匯損）", "匯率變動影響出口業獲利與壽險帳面"),
    (r"非農|就業|CPI|PCE|GDP", None, "整體市場（利率預期）", "經濟數據會影響降息／升息預期"),
    (r"外資", None, "大型權值股", "外資買賣超影響大型股走勢"),
]
OPP = {"偏多": "偏空", "偏空": "偏多"}

def rule_analyze(it):
    t = it["title"]; it.update(dir="中性", sectors="", why="")
    for pat, d, sec, why in RULES:
        if re.search(pat, t):
            if d is None:
                u, w = len(UP_W.findall(t)), len(DN_W.findall(t))
                d = "偏多" if u > w else "偏空" if w > u else "中性"
            elif FLIP.search(t):
                d, why = OPP[d], why + "（標題含緩和／反向字眼，已反向判斷）"
            it.update(dir=d, sectors=sec, why=why); break
    it["pro"], it["con"] = procon(it["dir"], it["why"])
    return it

def pick_top10(items, n=10):
    """最終輸出：前 n 則重點，保留欄位"""
    out = []
    for x in items[:n]:
        x.pop("ts", None); x.pop("score", None); x.pop("_hit", None); out.append(x)
    return out

def analyze_news(items):
    items = [rule_analyze(x) for x in items]
    for x in items:
        x["cat"] = classify(x["title"])
    items = score_items(items)
    cand = items[:25]
    mode, summ = "rule", []
    lines = "\n".join(f"{i}. [{x['cat']}] {x['title']}（{x['src']}）" for i, x in enumerate(cand))
    prompt = ("你是台股研究助理。以下是今日財經新聞標題。請從中挑出對台股與美股最重要的 10 則，依重要程度由高到低排序，只輸出 JSON："
              '{"summary":["今日整體對股市的重點，繁體中文，3~4句"],"items":[{"i":編號,"imp":重要度1到5,"dir":"偏多|偏空|中性",'
              '"sec":"可能受影響的產業或族群","im":"對股市的影響與傳導邏輯，1~2句","pro":"有利之處（利）","con":"不利或風險（弊）"}]}。'
              "規則：只根據標題推論，不要編造標題沒有的事實；不要推薦買賣個股；語氣保守並說明不確定性；繁體中文。\n\n" + lines)
    res = claude_json(prompt, 5000) if cand else None
    if res:
        chosen = []
        for o in res.get("items", []):
            try:
                x = cand[o["i"]]
                if x in chosen or o["dir"] not in ("偏多", "偏空", "中性"):
                    continue
                x.update(dir=o["dir"], sectors=str(o.get("sec", "")), why=str(o.get("im", "")), pro=str(o.get("pro", "")),
                         con=str(o.get("con", "")), imp=max(1, min(5, int(o.get("imp", 3)))))
                chosen.append(x)
            except Exception:
                continue
        if len(chosen) >= 5:
            mode, summ, items = "ai", [str(s) for s in res.get("summary", [])], chosen
    if mode == "rule":
        c = Counter(x["dir"] for x in items[:10])
        summ = [f"重點 10 則中：偏多 {c['偏多']} 則、偏空 {c['偏空']} 則、中性 {c['中性']} 則（依標題關鍵字與報導量推測）"]
        top = Counter((x["dir"], x["sectors"]) for x in items[:10] if x["dir"] != "中性" and x["sectors"]).most_common(3)
        summ += [f"{d}　{s}（{n} 則）" for (d, s), n in top]
    return dict(mode=mode, summary=summ, items=pick_top10(items))

# ---------- 通知 ----------
def build_text(up, dip, date, mk):
    lines = [f"📈 台股技術面訊號整理（{date} 收盤）", mk_line(mk), ""] if mk_line(mk) else [f"📈 台股技術面訊號整理（{date} 收盤）", ""]
    lines.append(f"【精選觀察】共 {up[1]} 檔" + ("" if up[0] else "，今日無"))
    lines += [f"{h['code']} {h['name']} {h['close']} ({h['pct']:+.1f}%)" for h in up[0][:5]]
    lines += ["", f"【超跌止跌】共 {dip[1]} 檔" + ("" if dip[0] else "，今日無")]
    lines += [f"{h['code']} {h['name']} {h['close']} 距高點{h['dd']}%" for h in dip[0][:10]]
    repo = os.getenv("GITHUB_REPOSITORY", "")
    if "/" in repo:
        o, r = repo.split("/"); lines += ["", f"完整頁面：https://{o}.github.io/{r}/"]
    lines.append("⚠️ 個人研究用資料整理，非投資建議、非買賣推薦，不保證獲利，請自行判斷並承擔風險")
    return "\n".join(lines)

def send_text(text):
    """送到已設定的 Discord／Telegram；沒設定就只印出。回傳是否有送出"""
    sent = False
    dc = os.getenv("DISCORD_WEBHOOK_URL")
    if dc:
        try:
            print("Discord", requests.post(dc, json={"content": text[:1900]}, timeout=30).status_code); sent = True
        except Exception as ex:
            print("Discord 失敗", ex)
    tg, chat = os.getenv("TELEGRAM_BOT_TOKEN"), os.getenv("TELEGRAM_CHAT_ID")
    if tg and chat:
        try:
            print("Telegram", requests.post(f"https://api.telegram.org/bot{tg}/sendMessage", json={"chat_id": chat, "text": text}, timeout=30).status_code); sent = True
        except Exception as ex:
            print("Telegram 失敗", ex)
    if not sent:
        print("（未設定通知）", text[:200])
    return sent

def notify(up, dip, date, mk):
    text = build_text(up, dip, date, mk)
    sent = False
    dc = os.getenv("DISCORD_WEBHOOK_URL")
    if dc:
        r = requests.post(dc, json={"content": text[:1900]}, timeout=30)
        print("Discord", r.status_code); sent = True
    tg, chat = os.getenv("TELEGRAM_BOT_TOKEN"), os.getenv("TELEGRAM_CHAT_ID")
    if tg and chat:
        r = requests.post(f"https://api.telegram.org/bot{tg}/sendMessage", json={"chat_id": chat, "text": text}, timeout=30)
        print("Telegram", r.status_code); sent = True
    if not sent:
        print("未設定通知，略過")

