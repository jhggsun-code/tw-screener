"""台指期（TX 大台指，近月連續合約）：日線歷史、最新行情、與加權指數的價差。資料來自期交所（TAIFEX）公開資料。
連續合約＝每天取「尚未到期的最近月份」；換月時把舊資料依前一日兩個合約的價差比例調整，避免出現假跳空。"""
import io, os, json, datetime as dt
import numpy as np, pandas as pd, requests

UA = {"User-Agent": "Mozilla/5.0 (personal research tool)", "Referer": "https://www.taifex.com.tw/cht/3/futDataDown",
      "Origin": "https://www.taifex.com.tw"}
DIAG = []

def note(m):
    DIAG.append(m); print("台指期:", m)
URL_CSV = "https://www.taifex.com.tw/cht/3/futDataDown"
URL_JSON = "https://openapi.taifex.com.tw/v1/DailyMarketReportFut"
DESC = ("台指期（TX，俗稱大台指）是以「台灣加權股價指數」為標的的期貨，每點 200 元，每月第三個星期三結算。"
        "日盤 08:45–13:45、夜盤 15:00–隔日 05:00，比現貨多出夜盤時段，常被當作預判隔日台股開盤方向的參考。這裡顯示的是『近月連續合約』，換月時已做價差調整。")

def third_wed(y, m):
    d = dt.date(y, m, 1)
    return d + dt.timedelta((2 - d.weekday()) % 7 + 14)

def expiry(ym):
    return third_wed(int(ym[:4]), int(ym[4:6]))

def num(x):
    try:
        v = float(str(x).replace(",", "").strip())
        return v if v == v and v > 0 else None
    except Exception:
        return None

def col(df, key):
    return next((c for c in df.columns if key in str(c)), None)

def parse_csv(text):
    """期交所『每日行情下載』CSV → {日期: {'202611': 收盤, ...}}（只取一般交易時段、月契約）"""
    df = pd.read_csv(io.StringIO(text))
    cd, cc, cm = col(df, "交易日期"), col(df, "契約"), col(df, "到期月份")
    cp, cs, ct = col(df, "收盤價"), col(df, "結算價"), col(df, "交易時段")
    if not (cd and cm and (cp or cs)):
        return {}
    out = {}
    for _, r in df.iterrows():
        if cc and str(r[cc]).strip() != "TX":
            continue
        if ct and "盤後" in str(r[ct]):
            continue
        ym = str(r[cm]).strip()
        if not (len(ym) == 6 and ym.isdigit()):
            continue
        d = pd.to_datetime(str(r[cd]).strip().replace("/", "-"), errors="coerce")
        p = num(r[cp]) if cp else None
        p = p or (num(r[cs]) if cs else None)
        if pd.isna(d) or not p:
            continue
        out.setdefault(d.date(), {})[ym] = p
    return out

def continuous(days):
    """days: {date: {ym: price}} → 調整後的近月連續 Series"""
    ds = sorted(days)
    raw, sel = [], []
    for d in ds:
        c = [ym for ym in days[d] if expiry(ym) >= d]
        if not c:
            continue
        ym = min(c)
        raw.append((d, days[d][ym])); sel.append(ym)
    if len(raw) < 2:
        return None
    adj, mult = [0.0] * len(raw), 1.0
    for i in range(len(raw) - 1, -1, -1):
        adj[i] = raw[i][1] * mult
        if i > 0 and sel[i] != sel[i - 1]:
            prev = days[raw[i - 1][0]]
            if sel[i] in prev and sel[i - 1] in prev:
                mult *= prev[sel[i]] / prev[sel[i - 1]]
    return pd.Series(adj, index=pd.to_datetime([d for d, _ in raw]))

def download(months=8, today=None):
    today = today or dt.date.today()
    days = {}
    start = (pd.Timestamp(today) - pd.DateOffset(months=months)).date().replace(day=1)
    while start <= today:
        end = min((pd.Timestamp(start) + pd.offsets.MonthEnd(0)).date(), today)
        try:
            r = requests.post(URL_CSV, headers=UA, timeout=40, data={
                "down_type": "1", "commodity_id": "TX", "queryStartDate": start.strftime("%Y/%m/%d"),
                "queryEndDate": end.strftime("%Y/%m/%d")})
            txt = None
            for enc in ("cp950", "big5", "utf-8-sig"):
                try:
                    txt = r.content.decode(enc); break
                except Exception:
                    pass
            if txt:
                for d, v in parse_csv(txt).items():
                    days.setdefault(d, {}).update(v)
        except Exception as e:
            print("台指期下載略過", start, e)
        start = (pd.Timestamp(end) + pd.Timedelta(days=1)).date()
    return days

def latest_json():
    """openapi 最新一個交易日的近月收盤 → (日期, 收盤, 漲跌)；失敗回傳 None"""
    try:
        rows = requests.get(URL_JSON, headers=UA, timeout=30).json()
        c = [x for x in rows if str(x.get("Contract", "")).strip() == "TX" and "盤後" not in str(x.get("TradingSession", ""))
             and len(str(x.get("ContractMonth(Week)", "")).strip()) == 6]
        if not c:
            return None
        d = pd.to_datetime(str(c[0].get("Date")), errors="coerce")
        c = [x for x in c if expiry(str(x["ContractMonth(Week)"]).strip()) >= d.date()]
        x = min(c, key=lambda x: str(x["ContractMonth(Week)"]).strip())
        p = num(x.get("Last")) or num(x.get("SettlementPrice"))
        try:
            ch = float(str(x.get("Change", "")).replace(",", "").replace("▲", "").replace("▼", "-").replace("+", "").strip())
        except Exception:
            ch = None
        return (d.date(), p, ch) if p else None
    except Exception as e:
        print("台指期 openapi 略過", e); return None

def series(hist_path="docs/tx_hist.json"):
    s = None
    try:
        days = download()
        note(f"期交所歷史資料解析到 {len(days)} 個交易日")
        s = continuous(days)
    except Exception as e:
        note(f"期交所歷史資料下載失敗：{str(e)[:60]}")
    if s is not None and len(s) >= 60:
        try:
            json.dump({"d": [x.strftime("%Y-%m-%d") for x in s.index[-300:]], "c": [round(float(v), 2) for v in s.iloc[-300:]]},
                      open(hist_path, "w", encoding="utf-8"))
        except Exception:
            pass
    elif os.path.exists(hist_path):                       # 備援：用之前累積的紀錄
        try:
            j = json.load(open(hist_path, encoding="utf-8"))
            s = pd.Series(j["c"], index=pd.to_datetime(j["d"]))
        except Exception:
            s = None
    if s is None:
        return None
    lt = latest_json()
    if lt and lt[1] and pd.Timestamp(lt[0]) > s.index[-1]:
        s = pd.concat([s, pd.Series([lt[1]], index=[pd.Timestamp(lt[0])])])
    return s if len(s) >= 30 else None

def market_item(index_eval, twii=None, twii_c=None):
    c, proxy = series(), False
    if c is None:
        lt = latest_json()
        note("最新一日行情：" + (f"{lt[0]} 收 {lt[1]}" if lt else "openapi 也取不到"))
        if lt and twii_c is not None and len(twii_c) >= 30:
            ref = twii_c.loc[:pd.Timestamp(lt[0])]
            base = float(ref.iloc[-1]) if len(ref) else float(twii_c.iloc[-1])
            c, proxy = twii_c + (lt[1] - base), True
            note("歷史資料不足，走勢與技術面改以「加權指數＋固定價差」近似")
    if c is None:
        return None
    last, prev = float(c.iloc[-1]), float(c.iloc[-2])
    it = dict(sym="TXF", name="台指期（近月）", e="📊", show=0,
              desc=DESC + (" ⚠️ 目前期交所歷史資料抓不到，走勢圖與技術面是用加權指數加上固定價差近似的，只供參考。" if proxy else ""),
              c=round(last, 2), p=round((last / prev - 1) * 100, 2), ch=round(last - prev, 2), d=str(c.index[-1].date()),
              sp=[round(float(x), 2) for x in c.iloc[-20:]], hist=[round(float(x), 2) for x in c.iloc[-100:]],
              dates=[x.strftime("%m-%d") for x in c.index[-100:]], ev=index_eval(c), proxy=proxy)
    if twii and twii.get("d") == it["d"]:
        it["basis"] = round(it["c"] - twii["c"], 2)
    return it
