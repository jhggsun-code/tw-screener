"""台股（含 ETF）每日技術面整理 + 美股龍頭 + 國際英文新聞 → 手機網頁 docs/"""
import os, re, sys, json, shutil, zlib, struct, datetime as dt
import numpy as np, pandas as pd, requests, yfinance as yf
from extras import get_market, get_news, analyze_news, notify
from us import get_us, get_enews, US_LIST
from events import build_events, get_releases, IND_TIPS, adapt_market

TOP_N, MIN_AVG_VOL, MIN_PRICE, HIST_DAYS = 15, 500_000, 10, 100
TZ = dt.timezone(dt.timedelta(hours=8))
HERE = os.path.dirname(os.path.abspath(__file__))
CODE_OK = re.compile(r"^(\d{4}|00\d{2,4}[A-Z]?)$")   # 4碼個股／ETF，如 2330、0050、00878、00679B
IND = {"01": "水泥", "02": "食品", "03": "塑膠", "04": "紡織", "05": "電機機械", "06": "電器電纜", "08": "玻璃陶瓷",
       "09": "造紙", "10": "鋼鐵", "11": "橡膠", "12": "汽車", "14": "建材營造", "15": "航運", "16": "觀光餐旅",
       "17": "金融保險", "18": "貿易百貨", "20": "其他", "21": "化學", "22": "生技醫療", "23": "油電燃氣",
       "24": "半導體", "25": "電腦週邊", "26": "光電", "27": "通信網路", "28": "電子零組件", "29": "電子通路",
       "30": "資訊服務", "31": "其他電子", "35": "綠能環保", "36": "數位雲端", "37": "運動休閒", "38": "居家生活",
       "32": "文化創意", "33": "農業科技", "34": "電子商務", "91": "存託憑證"}

def _rows(url):
    try:
        return requests.get(url, timeout=30).json()
    except Exception as e:
        print("下載失敗", url[-40:], e); return []

def pick(row, keys):
    for k in keys:
        if row.get(k) not in (None, "", "--"):
            return row[k]

def num(x):
    try:
        return round(float(str(x).replace(",", "")), 2)
    except Exception:
        return None

def get_universe():
    u = {}
    for x in _rows("https://openapi.twse.com.tw/v1/exchangeReport/STOCK_DAY_ALL"):
        c = pick(x, ["Code"])
        if c and CODE_OK.match(c):
            u[c + ".TW"] = dict(name=pick(x, ["Name"]) or c, mkt="上市")
    for x in _rows("https://www.tpex.org.tw/openapi/v1/tpex_mainboard_daily_close_quotes"):
        c = pick(x, ["SecuritiesCompanyCode"])
        if c and CODE_OK.match(c):
            u[c + ".TWO"] = dict(name=pick(x, ["CompanyName"]) or c, mkt="上櫃")
    return u

def get_fund():
    """本益比／殖利率／股價淨值比／產業（官方開放資料，欄位若變動則顯示「—」）"""
    f, ind = {}, {}
    for x in _rows("https://openapi.twse.com.tw/v1/exchangeReport/BWIBBU_ALL"):
        c = pick(x, ["Code", "證券代號"])
        if c:
            f[c] = dict(pe=num(pick(x, ["PEratio", "本益比"])), yd=num(pick(x, ["DividendYield", "殖利率(%)"])),
                        pb=num(pick(x, ["PBratio", "股價淨值比"])))
    for x in _rows("https://www.tpex.org.tw/openapi/v1/tpex_mainboard_peratio_analysis"):
        c = pick(x, ["SecuritiesCompanyCode", "股票代號"])
        if c:
            f[c] = dict(pe=num(pick(x, ["PriceEarningRatio", "本益比"])), yd=num(pick(x, ["YieldRatio", "殖利率(%)"])),
                        pb=num(pick(x, ["PriceBookRatio", "股價淨值比"])))
    for x in _rows("https://openapi.twse.com.tw/v1/opendata/t187ap03_L"):
        c, i = pick(x, ["公司代號", "Code"]), pick(x, ["產業別", "Industry"])
        if c and i:
            ind[c] = IND.get(str(i).strip().zfill(2), "")
    for x in _rows("https://www.tpex.org.tw/openapi/v1/mopsfin_t187ap03_O"):
        c = pick(x, ["公司代號", "SecuritiesCompanyCode", "Code"])
        i = pick(x, ["產業別", "SecuritiesIndustryCode", "Industry"])
        if c and i and c not in ind:
            ind[c] = IND.get(str(i).strip().zfill(2), "")
    return f, ind

def rsi(c, n=14):
    d = c.diff()
    up = d.clip(lower=0).ewm(alpha=1/n, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1/n, adjust=False).mean()
    return 100 - 100 / (1 + up / dn.replace(0, np.nan))

def evaluate(df):
    """單一標的的指標與訊號。tag: breakout突破 / prep接近突破 / dip跌深止跌 / near接近低檔支撐 / weak弱勢 / none"""
    df = df.dropna(subset=["Close", "Volume"])
    if len(df) < 5:
        return None
    c, v = df["Close"], df["Volume"]
    f = lambda x, n=2: round(float(x), n)
    last = c.iloc[-1]
    base = dict(tag="none", close=f(last), pct=f((last / c.iloc[-2] - 1) * 100), cg=f(last - c.iloc[-2]), vol_ratio=0, rsi=None, dd=0,
                hi20=None, lo60=None, lo10=None, ma20=None, ma60=None, stop=0, thin=1, why=[], buy="", ck="",
                h52=f(c.iloc[-250:].max()), l52=f(c.iloc[-250:].min()), r5=None, r20=None,
                vol=f(v.iloc[-1] / 1000, 0), turn=f(last * v.iloc[-1] / 1e8))
    if len(df) < 70:
        return base                      # 新上市：資料不足，只顯示基本資料
    ma5, ma20, ma60 = c.rolling(5).mean(), c.rolling(20).mean(), c.rolling(60).mean()
    macd = c.ewm(span=12, adjust=False).mean() - c.ewm(span=26, adjust=False).mean()
    hist = macd - macd.ewm(span=9, adjust=False).mean()
    r = rsi(c)
    hi20, lo60, lo10 = c.iloc[-21:-1].max(), c.iloc[-60:].min(), c.iloc[-10:].min()
    dd = (last / c.iloc[-120:].max() - 1) * 100
    vol_ratio = v.iloc[-1] / v.iloc[-21:-1].mean()
    liquid = v.iloc[-5:].mean() >= MIN_AVG_VOL and last >= MIN_PRICE
    trend = last > ma20.iloc[-1] > ma60.iloc[-1] and ma20.iloc[-1] > ma20.iloc[-6]
    breakout = (liquid and trend and last > hi20 and vol_ratio >= 1.5
                and hist.iloc[-1] > 0 and hist.iloc[-1] > hist.iloc[-2] and 55 <= r.iloc[-1] <= 80)
    prep = liquid and trend and hi20 * 0.97 <= last <= hi20 and hist.iloc[-1] > 0 and 50 <= r.iloc[-1] <= 72
    dip = (liquid and len(df) >= 120 and dd <= -30 and r.iloc[-6:-1].min() <= 30
           and r.iloc[-1] > r.iloc[-2] and last > ma5.iloc[-1] and last > c.iloc[-6:].min())
    near = liquid and last <= lo60 * 1.05 and r.iloc[-1] <= 40
    weak = last < ma20.iloc[-1] < ma60.iloc[-1] and ma20.iloc[-1] < ma20.iloc[-6]
    tag = ("breakout" if breakout else "prep" if prep else "dip" if dip
           else "near" if near else "weak" if weak else "none")
    stop = {"breakout": ma20.iloc[-1], "prep": ma20.iloc[-1], "dip": lo10, "near": lo60 * 0.97}.get(tag, 0)
    L, R, M20, M60, H20, L60 = f(last), f(r.iloc[-1], 1), f(ma20.iloc[-1]), f(ma60.iloc[-1]), f(hi20), f(lo60)
    why, buy = [], ""
    if tag == "breakout":
        why = [f"收盤 {L} 突破近20日高點 {H20}", f"成交量是20日均量的 {vol_ratio:.1f} 倍，量增確認突破",
               f"收盤 {L} > 月線 {M20} > 季線 {M60}，多頭排列且月線上彎",
               "MACD 柱狀體為正且持續擴大，動能轉強", f"RSI {R} 偏強但未過熱（55～80）"]
        buy = f"剛突破，追高風險較大；可留意回測 {M20}～{H20} 附近的表現"
    elif tag == "prep":
        why = [f"收盤 {L} > 月線 {M20} > 季線 {M60}，多頭排列且月線上彎",
               f"收盤距20日高點 {H20} 僅差 {(hi20 / last - 1) * 100:.1f}%，即將挑戰突破",
               "MACD 柱狀體為正，動能偏多", f"RSI {R}，位於偏強區（50～72）"]
        buy = f"收盤放量站上 {H20} 才算確認突破"
    elif tag == "dip":
        why = [f"股價自半年高點下跌 {f(dd, 1)}%，已跌深", f"近5日 RSI 曾低於30（超賣），目前回升至 {R}",
               "收盤站回5日線，且高於近6日低點，出現初步止跌跡象",
               "風險：跌深原因不明，請自行確認基本面與消息面"]
        buy = f"可留意是否站穩 {f(lo10)}，跌破視為止跌失敗"
    elif tag == "near":
        why = [f"股價 {L} 距近60日低點 {L60} 僅 {(last / lo60 - 1) * 100:.1f}%", f"RSI {R} 偏低（40以下）",
               "尚未出現止跌訊號（未站回5日線或RSI未回升）"]
        buy = f"可留意 {L60} 附近是否出現止跌，跌破 {f(stop, 1)} 代表支撐失效"
    elif tag == "weak":
        why = ["股價低於月線與季線，且月線持續下彎", "空頭排列，目前沒有任何買進訊號"]
    ck = "".join("1" if x else "0" for x in (last > ma20.iloc[-1], last > ma60.iloc[-1], ma20.iloc[-1] > ma20.iloc[-6],
                                              hist.iloc[-1] > 0, 50 <= r.iloc[-1] <= 75, vol_ratio >= 1))
    base.update(tag=tag, vol_ratio=f(vol_ratio, 1), rsi=R, dd=f(dd, 1), hi20=H20, lo60=L60, lo10=f(lo10), ma20=M20,
                ma60=M60, stop=f(stop, 1), thin=0 if liquid else 1, why=why, buy=buy, ck=ck,
                r5=f((last / c.iloc[-6] - 1) * 100), r20=f((last / c.iloc[-21] - 1) * 100))
    return base

def calc_flow(tvs, allst):
    """各產業今日成交值占全市場比重，相對近5日平均的增減 → 看資金從哪裡流向哪裡"""
    try:
        df = pd.DataFrame(tvs).dropna(how="all").iloc[-11:]
        if len(df) < 7:
            return None
        ind = {c: allst[c]["ind"] for c in df.columns if allst[c].get("ind") and not allst[c]["kind"]}
        df = df[list(ind)]
        sec = df.T.groupby(pd.Series(ind)).sum().T
        share = sec.div(sec.sum(axis=1), axis=0) * 100
        today, avg = share.iloc[-1], share.iloc[-6:-1].mean()
        base = sec.iloc[-6:-1].mean().replace(0, np.nan)
        cnt = pd.Series(ind).value_counts()
        rows = []
        for s in share.columns:
            if cnt[s] < 3 or s in ("其他", ""):
                continue
            mem = [c for c in ind if ind[c] == s]
            w = df.iloc[-1][mem].fillna(0)
            pct = sum(allst[c]["pct"] * w[c] for c in mem) / w.sum() if w.sum() > 0 else 0
            top = sorted(mem, key=lambda c: -w[c])[:3]
            rows.append(dict(ind=s, share=round(today[s], 2), avg=round(avg[s], 2), d=round(today[s] - avg[s], 2),
                             tn=round(sec.iloc[-1][s] / 1e8, 1), ratio=round(float(sec.iloc[-1][s] / base[s]), 2) if base[s] == base[s] else None,
                             pct=round(float(pct), 2), n=int(cnt[s]), sh=[round(float(x), 2) for x in share[s].iloc[-8:]],
                             top=[dict(code=c, name=allst[c]["name"], pct=allst[c]["pct"]) for c in top]))
        if len(rows) < 6:
            return None
        rows.sort(key=lambda r: -r["d"])
        inf, outf = rows[:6], rows[::-1][:6]
        tot, tavg = sec.iloc[-1].sum() / 1e8, sec.sum(axis=1).iloc[-6:-1].mean() / 1e8
        names = lambda L: "、".join(r["ind"] for r in L[:3])
        head = (f"資金由「{names(outf)}」轉向「{names(inf)}」。" if inf[0]["d"] > 0.2 else "各族群資金分布與近5日差異不大。") + \
               f"（上市櫃個股合計成交值約 {tot:,.0f} 億，為近5日平均的 {tot / tavg:.2f} 倍）"
        return dict(headline=head, total=round(float(tot)), ratio=round(float(tot / tavg), 2), inflow=inf, outflow=outf,
                    rows=[dict(ind=r["ind"], d=r["d"], pct=r["pct"]) for r in rows])
    except Exception as e:
        print("資金流向計算失敗", e); return None

def calc_breadth(allst):
    """市場寬度：上漲／下跌家數、站上月線／季線比例、接近52週高低點家數（不含 ETF）"""
    S = [x for x in allst.values() if not x["kind"] and len(x.get("ck", "")) == 6]
    if len(S) < 50:
        return None
    adv, dec = sum(1 for x in S if x["pct"] > 0), sum(1 for x in S if x["pct"] < 0)
    r = adv / max(1, adv + dec)
    b = dict(adv=adv, dec=dec, flat=len(S) - adv - dec, n=len(S), a20=round(sum(x["ck"][0] == "1" for x in S) / len(S) * 100),
                a60=round(sum(x["ck"][1] == "1" for x in S) / len(S) * 100),
                hi=sum(1 for x in S if x["h52"] and x["close"] >= x["h52"] * 0.98),
                lo=sum(1 for x in S if x["l52"] and x["close"] <= x["l52"] * 1.05),
                mood="多方氣氛" if r > 0.6 else "空方氣氛" if r < 0.4 else "多空拉鋸",
                temp=0, label="")
    b["temp"] = round((b["a20"] + b["a60"]) / 2)
    b["label"] = "過熱" if b["temp"] >= 75 else "偏熱" if b["temp"] >= 60 else "中性" if b["temp"] >= 40 else "偏冷" if b["temp"] >= 25 else "低迷"
    return b

def pick_score(x):
    """技術面綜合評分（0~100）：訊號強度、6項檢查、量能、RSI 位置、近期漲幅是否過熱、流動性。只用於排序，不是買賣建議。"""
    if x["kind"] or x["thin"] or x["tag"] not in ("breakout", "prep"):
        return None
    s = {"breakout": 40, "prep": 28}[x["tag"]] + sum(ch == "1" for ch in x["ck"]) * 6 + min(x["vol_ratio"], 3) * 5
    r, g = x["rsi"] or 0, x["r20"] or 0
    s += 8 if 55 <= r <= 70 else 3 if 70 < r <= 78 else -8 if r > 78 else 0
    s += 6 if 3 <= g <= 25 else -6 if g > 35 else 0
    s += min(x["turn"], 50) / 50 * 6
    return min(100, round(s / 111 * 100))

def pick_top(A, k=5):
    c = sorted([(pick_score(x), x) for x in A if pick_score(x) is not None], key=lambda t: (-t[0], -t[1]["turn"]))
    out, cnt = [], {}
    for sc, x in c:
        if cnt.get(x["ind"], 0) >= 2:
            continue
        cnt[x["ind"]] = cnt.get(x["ind"], 0) + 1
        out.append(dict(x, sc=sc))
        if len(out) >= k:
            break
    return out, len(c)

def scan():
    uni, (fund, ind) = get_universe(), get_fund()
    tickers, allst, hist, last, ref, tvs = list(uni), {}, {}, None, None, {}
    for i in range(0, len(tickers), 150):
        chunk = tickers[i:i+150]
        try:
            data = yf.download(chunk, period="1y", group_by="ticker", progress=False, threads=True, auto_adjust=True)
        except Exception as e:
            print("下載失敗", e); continue
        for t in chunk:
            try:
                d = data[t]; cl = d["Close"].dropna()
                if cl.empty:
                    continue
                day = cl.index[-1].date(); last = day if last is None or day > last else last
                res = evaluate(d)
                if not res:
                    continue
                code, fd = t.split(".")[0], fund.get(t.split(".")[0], {})
                res.update(code=code, name=uni[t]["name"], mkt=uni[t]["mkt"], kind="ETF" if code.startswith("00") else "",
                           ind=ind.get(code, ""), pe=fd.get("pe"), yd=fd.get("yd"), pb=fd.get("pb"))
                allst[code] = res
                tvs[code] = (d["Close"] * d["Volume"]).dropna().iloc[-11:]
                hist[code] = [round(float(x), 2) for x in cl.iloc[-HIST_DAYS:]]
                if ref is None or len(cl) > len(ref):
                    ref = cl.index
            except Exception:
                continue
    A = list(allst.values()); liq = [s for s in A if not s["thin"]]
    lists = dict(up=sorted([s for s in A if s["tag"] == "breakout"], key=lambda x: -x["vol_ratio"]),
                 dip=sorted([s for s in A if s["tag"] == "dip"], key=lambda x: x["dd"]),
                 gain=sorted(liq, key=lambda x: -x["pct"])[:10], act=sorted(liq, key=lambda x: -x["turn"])[:10])
    lists["pick"], lists["pick_n"] = pick_top(A)
    dates = [x.strftime("%m-%d") for x in ref[-HIST_DAYS:]] if ref is not None else []
    return lists, allst, hist, dates, last, calc_flow(tvs, allst)

# ---------- 輸出網頁 ----------
def make_png(size, path):
    rows = []
    for y in range(size):
        row = bytearray([0]); fy = y / size
        for x in range(size):
            fx = x / size
            inside = 0.25 <= fy <= 0.72 and abs(fx - 0.5) <= (fy - 0.25) / 0.47 * 0.27
            row += bytes((255, 255, 255)) if inside else bytes((59, 111, 224))
        rows.append(bytes(row))
    def chunk(t, d):
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    open(path, "wb").write(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 2, 0, 0, 0))
                           + chunk(b"IDAT", zlib.compress(b"".join(rows), 9)) + chunk(b"IEND", b""))

MANIFEST = {"name": "台股每日選股", "short_name": "台股選股", "start_url": "./", "scope": "./", "display": "standalone",
            "background_color": "#3b6fe0", "theme_color": "#3b6fe0",
            "icons": [{"src": "icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any maskable"},
                      {"src": "icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any maskable"}]}
SW = """self.addEventListener('install',e=>self.skipWaiting());
self.addEventListener('activate',e=>e.waitUntil(clients.claim()));
self.addEventListener('fetch',e=>{e.respondWith(fetch(e.request).then(r=>{var c=r.clone();
caches.open('v1').then(x=>x.put(e.request,c));return r;}).catch(()=>caches.match(e.request)));});"""

def pack(x):
    """壓縮欄位：n名稱 t狀態 c收盤 p漲跌% r RSI d距半年高% v量比 s技術價位 k量少 b觀察重點 w原因 e ETF x市場
    i產業 pe/y/pb 估值 h/l 52週高低 a月線 z季線 q成交量(張) tn成交值(億) g5/g20 近5/20日% ck 6項檢查"""
    o = dict(n=x["name"], t=x["tag"], c=x["close"], p=x["pct"], cg=x["cg"], sc=x.get("sc"), r=x["rsi"], d=x["dd"], v=x["vol_ratio"], s=x["stop"],
             k=x["thin"], b=x["buy"], w=x["why"], e=1 if x["kind"] else 0, x=x["mkt"], i=x["ind"], pe=x["pe"], y=x["yd"],
             pb=x["pb"], h=x["h52"], l=x["l52"], a=x["ma20"], z=x["ma60"], q=x["vol"], tn=x["turn"], g5=x["r5"],
             g20=x["r20"], ck=x["ck"])
    return {k: v for k, v in o.items() if v not in (None, "", [], 0) or k in ("c", "p", "t")}

def write_site(lists, allst, hist, dates, date, mk, nw, us, en, flow=None, events=None):
    os.makedirs("docs", exist_ok=True)
    upd = dt.datetime.now(TZ).strftime("%m/%d %H:%M")
    W = lambda name, obj, **kw: json.dump(obj, open("docs/" + name, "w", encoding="utf-8"), ensure_ascii=False, **kw)
    top = lambda lst: [dict(code=x["code"], **pack(x)) for x in lst[:TOP_N]]
    W("data.json", {"date": str(date), "updated": upd,
                    "up": {"total": len(lists["up"]), "stocks": top(lists["up"])},
                    "dip": {"total": len(lists["dip"]), "stocks": top(lists["dip"])},
                    "gain": {"stocks": top(lists["gain"])}, "act": {"stocks": top(lists["act"])}, "flow": flow, "breadth": calc_breadth(allst),
                    "pick": {"stocks": top(lists["pick"]), "total": lists["pick_n"]}})
    W("stocks.json", {"date": str(date), "s": {c: pack(x) for c, x in allst.items()}}, separators=(",", ":"))
    W("hist.json", {"d": dates, "s": hist}, separators=(",", ":"))
    W("market.json", dict(mk, updated=upd)); W("news.json", dict(nw, updated=upd))
    W("us.json", dict(us, updated=upd), separators=(",", ":")); W("enews.json", dict(en, updated=upd))
    W("events.json", events or dict(gen=str(date), events=[], links={}))
    html = open(os.path.join(HERE, "page.html"), encoding="utf-8").read().replace("__V__", dt.datetime.now(TZ).strftime("%m%d%H%M"))
    open("docs/index.html", "w", encoding="utf-8").write(html)
    for f in ("app.css", "app.js"):
        shutil.copy(os.path.join(HERE, f), "docs/" + f)
    W("manifest.json", MANIFEST)
    open("docs/sw.js", "w").write(SW); open("docs/robots.txt", "w").write("User-agent: *\nDisallow: /\n")
    make_png(192, "docs/icon-192.png"); make_png(512, "docs/icon-512.png")

def safe(fn, default, *a):
    try:
        return fn(*a)
    except Exception as e:
        print("略過", getattr(fn, "__name__", fn), e); return default

if __name__ == "__main__":
    lists, allst, hist, dates, date, flow = scan()
    if len(allst) < 100:
        print("❌ 台股資料抓取失敗（只取得", len(allst), "檔），保留舊資料不更新"); sys.exit(1)
    date = date or dt.datetime.now(TZ).date()
    mk = safe(lambda: adapt_market(get_market()), dict(items=[], hint=[], dates=[], cycle=None, ndc=None))
    nw = safe(lambda: analyze_news(get_news()), dict(mode="rule", summary=[], items=[]))
    us = safe(get_us, dict(items=[], dates=[]), evaluate)
    en = safe(get_enews, dict(mode="en", brief=[], items=[]))
    ev = dict(events=safe(build_events, []), latest=safe(get_releases, []), er=us.get("er", dict(up=[], res=[])), ind=IND_TIPS)
    write_site(lists, allst, hist, dates, date, mk, nw, us, en, flow, ev)
    notify((lists["up"][:TOP_N], len(lists["up"])), (lists["dip"][:TOP_N], len(lists["dip"])), date, mk)
