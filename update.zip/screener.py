"""台股（含 ETF）每日技術面整理 + 美股龍頭 + 國際英文新聞 → 手機網頁 docs/"""
import os, re, sys, json, shutil, zlib, struct, datetime as dt
import numpy as np, pandas as pd, requests, yfinance as yf
from extras import get_market, get_news, analyze_news, notify
from us import get_us, get_enews

TOP_N, MIN_AVG_VOL, MIN_PRICE, HIST_DAYS = 15, 500_000, 10, 100
TZ = dt.timezone(dt.timedelta(hours=8))
HERE = os.path.dirname(os.path.abspath(__file__))
CODE_OK = re.compile(r"^(\d{4}|00\d{2,4}[A-Z]?)$")   # 4碼個股／ETF，如 2330、0050、00878、00679B
IND = {"01": "水泥", "02": "食品", "03": "塑膠", "04": "紡織", "05": "電機機械", "06": "電器電纜", "08": "玻璃陶瓷",
       "09": "造紙", "10": "鋼鐵", "11": "橡膠", "12": "汽車", "14": "建材營造", "15": "航運", "16": "觀光餐旅",
       "17": "金融保險", "18": "貿易百貨", "20": "其他", "21": "化學", "22": "生技醫療", "23": "油電燃氣",
       "24": "半導體", "25": "電腦週邊", "26": "光電", "27": "通信網路", "28": "電子零組件", "29": "電子通路",
       "30": "資訊服務", "31": "其他電子", "35": "綠能環保", "36": "數位雲端", "37": "運動休閒", "38": "居家生活",
       "91": "存託憑證"}

def _rows(url):
    try:
        return requests.get(url, timeout=30).json()
    except Exception as e:
        print("下載失敗", url[-40:], e); return []

def pick(row, keys):
    for k in keys:
        if row.get(k) not in (None, "", "--"):
            return row[k]

def num(x):
    try:
        return round(float(str(x).replace(",", "")), 2)
    except Exception:
        return None

def get_universe():
    u = {}
    for x in _rows("https://openapi.twse.com.tw/v1/exchangeReport/STOCK_DAY_ALL"):
        c = pick(x, ["Code"])
        if c and CODE_OK.match(c):
            u[c + ".TW"] = dict(name=pick(x, ["Name"]) or c, mkt="上市")
    for x in _rows("https://www.tpex.org.tw/openapi/v1/tpex_mainboard_daily_close_quotes"):
        c = pick(x, ["SecuritiesCompanyCode"])
        if c and CODE_OK.match(c):
            u[c + ".TWO"] = dict(name=pick(x, ["CompanyName"]) or c, mkt="上櫃")
    return u

def get_fund():
    """本益比／殖利率／股價淨值比／產業（官方開放資料，欄位若變動則顯示「—」）"""
    f, ind = {}, {}
    for x in _rows("https://openapi.twse.com.tw/v1/exchangeReport/BWIBBU_ALL"):
        c = pick(x, ["Code", "證券代號"])
        if c:
            f[c] = dict(pe=num(pick(x, ["PEratio", "本益比"])), yd=num(pick(x, ["DividendYield", "殖利率(%)"])),
                        pb=num(pick(x, ["PBratio", "股價淨值比"])))
    for x in _rows("https://www.tpex.org.tw/openapi/v1/tpex_mainboard_peratio_analysis"):
        c = pick(x, ["SecuritiesCompanyCode", "股票代號"])
        if c:
            f[c] = dict(pe=num(pick(x, ["PriceEarningRatio", "本益比"])), yd=num(pick(x, ["YieldRatio", "殖利率(%)"])),
                        pb=num(pick(x, ["PriceBookRatio", "股價淨值比"])))
    for x in _rows("https://openapi.twse.com.tw/v1/opendata/t187ap03_L"):
        c, i = pick(x, ["公司代號", "Code"]), pick(x, ["產業別", "Industry"])
        if c and i:
            ind[c] = IND.get(str(i).strip().zfill(2), "")
    return f, ind

def rsi(c, n=14):
    d = c.diff()
    up = d.clip(lower=0).ewm(alpha=1/n, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1/n, adjust=False).mean()
    return 100 - 100 / (1 + up / dn.replace(0, np.nan))

def evaluate(df):
    """單一標的的指標與訊號。tag: breakout突破 / prep接近突破 / dip跌深止跌 / near接近低檔支撐 / weak弱勢 / none"""
    df = df.dropna(subset=["Close", "Volume"])
    if len(df) < 5:
        return None
    c, v = df["Close"], df["Volume"]
    f = lambda x, n=2: round(float(x), n)
    last = c.iloc[-1]
    base = dict(tag="none", close=f(last), pct=f((last / c.iloc[-2] - 1) * 100), vol_ratio=0, rsi=None, dd=0,
                hi20=None, lo60=None, lo10=None, ma20=None, ma60=None, stop=0, thin=1, why=[], buy="", ck="",
                h52=f(c.iloc[-250:].max()), l52=f(c.iloc[-250:].min()), r5=None, r20=None,
                vol=f(v.iloc[-1] / 1000, 0), turn=f(last * v.iloc[-1] / 1e8))
    if len(df) < 70:
        return base                      # 新上市：資料不足，只顯示基本資料
    ma5, ma20, ma60 = c.rolling(5).mean(), c.rolling(20).mean(), c.rolling(60).mean()
    macd = c.ewm(span=12, adjust=False).mean() - c.ewm(span=26, adjust=False).mean()
    hist = macd - macd.ewm(span=9, adjust=False).mean()
    r = rsi(c)
    hi20, lo60, lo10 = c.iloc[-21:-1].max(), c.iloc[-60:].min(), c.iloc[-10:].min()
    dd = (last / c.iloc[-120:].max() - 1) * 100
    vol_ratio = v.iloc[-1] / v.iloc[-21:-1].mean()
    liquid = v.iloc[-5:].mean() >= MIN_AVG_VOL and last >= MIN_PRICE
    trend = last > ma20.iloc[-1] > ma60.iloc[-1] and ma20.iloc[-1] > ma20.iloc[-6]
    breakout = (liquid and trend and last > hi20 and vol_ratio >= 1.5
                and hist.iloc[-1] > 0 and hist.iloc[-1] > hist.iloc[-2] and 55 <= r.iloc[-1] <= 80)
    prep = liquid and trend and hi20 * 0.97 <= last <= hi20 and hist.iloc[-1] > 0 and 50 <= r.iloc[-1] <= 72
    dip = (liquid and len(df) >= 120 and dd <= -30 and r.iloc[-6:-1].min() <= 30
           and r.iloc[-1] > r.iloc[-2] and last > ma5.iloc[-1] and last > c.iloc[-6:].min())
    near = liquid and last <= lo60 * 1.05 and r.iloc[-1] <= 40
    weak = last < ma20.iloc[-1] < ma60.iloc[-1] and ma20.iloc[-1] < ma20.iloc[-6]
    tag = ("breakout" if breakout else "prep" if prep else "dip" if dip
           else "near" if near else "weak" if weak else "none")
    stop = {"breakout": ma20.iloc[-1], "prep": ma20.iloc[-1], "dip": lo10, "near": lo60 * 0.97}.get(tag, 0)
    L, R, M20, M60, H20, L60 = f(last), f(r.iloc[-1], 1), f(ma20.iloc[-1]), f(ma60.iloc[-1]), f(hi20), f(lo60)
    why, buy = [], ""
    if tag == "breakout":
        why = [f"收盤 {L} 突破近20日高點 {H20}", f"成交量是20日均量的 {vol_ratio:.1f} 倍，量增確認突破",
               f"收盤 {L} > 月線 {M20} > 季線 {M60}，多頭排列且月線上彎",
               "MACD 柱狀體為正且持續擴大，動能轉強", f"RSI {R} 偏強但未過熱（55～80）"]
        buy = f"剛突破，追高風險較大；可留意回測 {M20}～{H20} 附近的表現"
    elif tag == "prep":
        why = [f"收盤 {L} > 月線 {M20} > 季線 {M60}，多頭排列且月線上彎",
               f"收盤距20日高點 {H20} 僅差 {(hi20 / last - 1) * 100:.1f}%，即將挑戰突破",
               "MACD 柱狀體為正，動能偏多", f"RSI {R}，位於偏強區（50～72）"]
        buy = f"收盤放量站上 {H20} 才算確認突破"
    elif tag == "dip":
        why = [f"股價自半年高點下跌 {f(dd, 1)}%，已跌深", f"近5日 RSI 曾低於30（超賣），目前回升至 {R}",
               "收盤站回5日線，且高於近6日低點，出現初步止跌跡象",
               "風險：跌深原因不明，請自行確認基本面與消息面"]
        buy = f"可留意是否站穩 {f(lo10)}，跌破視為止跌失敗"
    elif tag == "near":
        why = [f"股價 {L} 距近60日低點 {L60} 僅 {(last / lo60 - 1) * 100:.1f}%", f"RSI {R} 偏低（40以下）",
               "尚未出現止跌訊號（未站回5日線或RSI未回升）"]
        buy = f"可留意 {L60} 附近是否出現止跌，跌破 {f(stop, 1)} 代表支撐失效"
    elif tag == "weak":
        why = ["股價低於月線與季線，且月線持續下彎", "空頭排列，目前沒有任何買進訊號"]
    ck = "".join("1" if x else "0" for x in (last > ma20.iloc[-1], last > ma60.iloc[-1], ma20.iloc[-1] > ma20.iloc[-6],
                                              hist.iloc[-1] > 0, 50 <= r.iloc[-1] <= 75, vol_ratio >= 1))
    base.update(tag=tag, vol_ratio=f(vol_ratio, 1), rsi=R, dd=f(dd, 1), hi20=H20, lo60=L60, lo10=f(lo10), ma20=M20,
                ma60=M60, stop=f(stop, 1), thin=0 if liquid else 1, why=why, buy=buy, ck=ck,
                r5=f((last / c.iloc[-6] - 1) * 100), r20=f((last / c.iloc[-21] - 1) * 100))
    return base

def scan():
    uni, (fund, ind) = get_universe(), get_fund()
    tickers, allst, hist, last, ref = list(uni), {}, {}, None, None
    for i in range(0, len(tickers), 150):
        chunk = tickers[i:i+150]
        try:
            data = yf.download(chunk, period="1y", group_by="ticker", progress=False, threads=True, auto_adjust=True)
        except Exception as e:
            print("下載失敗", e); continue
        for t in chunk:
            try:
                d = data[t]; cl = d["Close"].dropna()
                if cl.empty:
                    continue
                day = cl.index[-1].date(); last = day if last is None or day > last else last
                res = evaluate(d)
                if not res:
                    continue
                code, fd = t.split(".")[0], fund.get(t.split(".")[0], {})
                res.update(code=code, name=uni[t]["name"], mkt=uni[t]["mkt"], kind="ETF" if code.startswith("00") else "",
                           ind=ind.get(code, ""), pe=fd.get("pe"), yd=fd.get("yd"), pb=fd.get("pb"))
                allst[code] = res
                hist[code] = [round(float(x), 2) for x in cl.iloc[-HIST_DAYS:]]
                if ref is None or len(cl) > len(ref):
                    ref = cl.index
            except Exception:
                continue
    A = list(allst.values()); liq = [s for s in A if not s["thin"]]
    lists = dict(up=sorted([s for s in A if s["tag"] == "breakout"], key=lambda x: -x["vol_ratio"]),
                 dip=sorted([s for s in A if s["tag"] == "dip"], key=lambda x: x["dd"]),
                 gain=sorted(liq, key=lambda x: -x["pct"])[:10], act=sorted(liq, key=lambda x: -x["turn"])[:10])
    dates = [x.strftime("%m-%d") for x in ref[-HIST_DAYS:]] if ref is not None else []
    return lists, allst, hist, dates, last

# ---------- 輸出網頁 ----------
def make_png(size, path):
    rows = []
    for y in range(size):
        row = bytearray([0]); fy = y / size
        for x in range(size):
            fx = x / size
            inside = 0.25 <= fy <= 0.72 and abs(fx - 0.5) <= (fy - 0.25) / 0.47 * 0.27
            row += bytes((255, 255, 255)) if inside else bytes((198, 40, 40))
        rows.append(bytes(row))
    def chunk(t, d):
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    open(path, "wb").write(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 2, 0, 0, 0))
                           + chunk(b"IDAT", zlib.compress(b"".join(rows), 9)) + chunk(b"IEND", b""))

MANIFEST = {"name": "台股每日選股", "short_name": "台股選股", "start_url": "./", "scope": "./", "display": "standalone",
            "background_color": "#d32f2f", "theme_color": "#d32f2f",
            "icons": [{"src": "icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any maskable"},
                      {"src": "icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any maskable"}]}
SW = """self.addEventListener('install',e=>self.skipWaiting());
self.addEventListener('activate',e=>e.waitUntil(clients.claim()));
self.addEventListener('fetch',e=>{e.respondWith(fetch(e.request).then(r=>{var c=r.clone();
caches.open('v1').then(x=>x.put(e.request,c));return r;}).catch(()=>caches.match(e.request)));});"""

def pack(x):
    """壓縮欄位：n名稱 t狀態 c收盤 p漲跌% r RSI d距半年高% v量比 s技術價位 k量少 b觀察重點 w原因 e ETF x市場
    i產業 pe/y/pb 估值 h/l 52週高低 a月線 z季線 q成交量(張) tn成交值(億) g5/g20 近5/20日% ck 6項檢查"""
    o = dict(n=x["name"], t=x["tag"], c=x["close"], p=x["pct"], r=x["rsi"], d=x["dd"], v=x["vol_ratio"], s=x["stop"],
             k=x["thin"], b=x["buy"], w=x["why"], e=1 if x["kind"] else 0, x=x["mkt"], i=x["ind"], pe=x["pe"], y=x["yd"],
             pb=x["pb"], h=x["h52"], l=x["l52"], a=x["ma20"], z=x["ma60"], q=x["vol"], tn=x["turn"], g5=x["r5"],
             g20=x["r20"], ck=x["ck"])
    return {k: v for k, v in o.items() if v not in (None, "", [], 0) or k in ("c", "p", "t")}

def write_site(lists, allst, hist, dates, date, mk, nw, us, en):
    os.makedirs("docs", exist_ok=True)
    upd = dt.datetime.now(TZ).strftime("%m/%d %H:%M")
    W = lambda name, obj, **kw: json.dump(obj, open("docs/" + name, "w", encoding="utf-8"), ensure_ascii=False, **kw)
    top = lambda lst: [dict(code=x["code"], **pack(x)) for x in lst[:TOP_N]]
    W("data.json", {"date": str(date), "updated": upd,
                    "up": {"total": len(lists["up"]), "stocks": top(lists["up"])},
                    "dip": {"total": len(lists["dip"]), "stocks": top(lists["dip"])},
                    "gain": {"stocks": top(lists["gain"])}, "act": {"stocks": top(lists["act"])}})
    W("stocks.json", {"date": str(date), "s": {c: pack(x) for c, x in allst.items()}}, separators=(",", ":"))
    W("hist.json", {"d": dates, "s": hist}, separators=(",", ":"))
    W("market.json", dict(mk, updated=upd)); W("news.json", dict(nw, updated=upd))
    W("us.json", dict(us, updated=upd), separators=(",", ":")); W("enews.json", dict(en, updated=upd))
    html = open(os.path.join(HERE, "page.html"), encoding="utf-8").read().replace("__V__", dt.datetime.now(TZ).strftime("%m%d%H%M"))
    open("docs/index.html", "w", encoding="utf-8").write(html)
    for f in ("app.css", "app.js"):
        shutil.copy(os.path.join(HERE, f), "docs/" + f)
    W("manifest.json", MANIFEST)
    open("docs/sw.js", "w").write(SW); open("docs/robots.txt", "w").write("User-agent: *\nDisallow: /\n")
    make_png(192, "docs/icon-192.png"); make_png(512, "docs/icon-512.png")

def safe(fn, default, *a):
    try:
        return fn(*a)
    except Exception as e:
        print("略過", getattr(fn, "__name__", fn), e); return default

if __name__ == "__main__":
    lists, allst, hist, dates, date = scan()
    if len(allst) < 100:
        print("❌ 台股資料抓取失敗（只取得", len(allst), "檔），保留舊資料不更新"); sys.exit(1)
    date = date or dt.datetime.now(TZ).date()
    mk = safe(get_market, dict(items=[], hint=[]))
    nw = safe(lambda: analyze_news(get_news()), dict(mode="rule", summary=[], items=[]))
    us = safe(get_us, dict(items=[], dates=[]), evaluate)
    en = safe(get_enews, dict(mode="en", brief=[], items=[]))
    write_site(lists, allst, hist, dates, date, mk, nw, us, en)
    notify((lists["up"][:TOP_N], len(lists["up"])), (lists["dip"][:TOP_N], len(lists["dip"])), date, mk)
