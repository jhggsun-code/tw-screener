"""盤中／收盤後報價更新（Yahoo 延遲約 15～20 分鐘）→ quotes_out/quotes.json
台股時段更新台股，美股時段更新美股與指數；手動執行則全部更新。"""
import os, json, datetime as dt
import requests, yfinance as yf
import twse
from us import US_LIST

TZ = dt.timezone(dt.timedelta(hours=8))
IDX_TW = ["^TWII", "^KS11", "^N225"]
IDX_US = ["^DJI", "^GSPC", "^IXIC", "^SOX", "^VIX", "^TNX", "TWD=X"]

def batch(syms, size=150):
    out = {}
    for i in range(0, len(syms), size):
        part = syms[i:i + size]
        try:
            d = yf.download(part, period="5d", group_by="ticker", progress=False, threads=True, auto_adjust=False)
        except Exception as e:
            print("下載失敗", e); continue
        for s in part:
            try:
                c = d[s]["Close"].dropna()
                if len(c) >= 2:
                    out[s] = (round(float(c.iloc[-1]), 2), round(float(c.iloc[-1] / c.iloc[-2] - 1) * 100, 2),
                              round(float(c.iloc[-1] - c.iloc[-2]), 3), str(c.index[-1].date()))
            except Exception:
                pass
    return out

def main():
    mode = os.getenv("QMODE") or "all"
    h = dt.datetime.now(dt.timezone.utc).hour
    if mode == "auto":
        mode = "tw" if 1 <= h <= 12 else "us"   # UTC 01～12 = 台灣 09:00～20:59
    repo = os.getenv("GITHUB_REPOSITORY", "")
    try:
        q = requests.get(f"https://raw.githubusercontent.com/{repo}/quotes/quotes.json", timeout=20).json() if repo else {}
    except Exception:
        q = {}
    if mode in ("tw", "all"):
        try:
            stocks = json.load(open("docs/stocks.json", encoding="utf-8"))["s"]
            m = {c + (".TWO" if x.get("x") == "上櫃" else ".TW"): c for c, x in stocks.items()}
            r = batch(list(m))
            if len(r) > 100:
                q["tw"] = {m[s]: [v[0], v[1], v[2]] for s, v in r.items()}
                q["tw_d"] = max(v[3] for v in r.values())
        except Exception as e:
            print("台股報價略過", e)
        try:   # 收盤後：用證交所／櫃買官方資料直接蓋過 Yahoo（Yahoo 常晚幾小時才有當日收盤）
            bars = twse.official_bars(); od = twse.latest_date(bars)
            if od and od == twse.today() and len(bars) > 100:
                q.setdefault("tw", {}).update({c: [b["c"], twse.pct(b), round(b["chg"], 2)] for c, b in bars.items() if c in stocks})
                q["tw_d"] = str(od); print("已套用官方當日收盤", od)
        except Exception as e:
            print("官方收盤略過", e)
        r2 = batch(IDX_TW)
        q.setdefault("ix", {}).update({s: [r2[s][0], r2[s][1], r2[s][2]] for s in IDX_TW if s in r2})
        try:
            o = twse.official_twii()
            if o and o["d"] == twse.today():
                q.setdefault("ix", {})["^TWII"] = [o["c"], round(o["chg"] / (o["c"] - o["chg"]) * 100, 2), round(o["chg"], 2)]
        except Exception as e:
            print("加權指數官方收盤略過", e)
    if mode in ("us", "all"):
        r = batch([s for s, _, _ in US_LIST] + IDX_US)
        if r:
            q["us"] = {s: [r[s][0], r[s][1], r[s][2]] for s, _, _ in US_LIST if s in r}
            q.setdefault("ix", {}).update({s: [r[s][0], r[s][1], r[s][2]] for s in IDX_US if s in r})
            q["us_d"] = max(r[s][3] for s in q["us"]) if q["us"] else ""
    q["upd"] = dt.datetime.now(TZ).strftime("%m/%d %H:%M")
    os.makedirs("quotes_out", exist_ok=True)
    json.dump(q, open("quotes_out/quotes.json", "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))
    print("quotes:", {k: (len(v) if isinstance(v, dict) else v) for k, v in q.items()})

if __name__ == "__main__":
    main()
