"""行事曆提醒、官方最新公布、經濟數據速查，以及把指標資料整理成網頁需要的格式"""
import re, html, email.utils, datetime as dt
import xml.etree.ElementTree as ET
import requests, yfinance as yf
import cal
from extras import UA, TZ

def build_events(today=None):
    """台股結算日／休市、美股三巫日／FOMC／非農／CPI 等（財報另由 us.py 提供）→ 網頁格式"""
    today = today or dt.datetime.now(TZ).date()
    ev, _ = cal.build_events(today, None)
    out = []
    for e in ev:
        if e["k"] == "earn":
            continue
        d = dt.date.fromisoformat(e["d"])
        out.append(dict(d=e["d"], md=d.strftime("%m/%d"), wd=e["wd"], mk="tw" if e["m"] == "TW" else "us", title=e["n"],
                        tip=(e["w"] + " " + e["x"]).strip(), est=("（約）" in e["w"]) or ("預定" in e["w"])))
    out.sort(key=lambda e: (e["d"], e["mk"]))
    return out


WATCH = {"TXF": "看與加權指數的價差：正價差（期貨高於現貨）代表市場偏樂觀，逆價差代表偏保守或避險；結算前價差會逐漸收斂到 0。夜盤的漲跌常被拿來預判隔天台股開盤。",
         "^DJI": "看收盤是否站上月線／季線、是否創高。道瓊以傳統大型股為主，與那斯達克走勢分歧時，代表資金正在換族群。",
         "^GSPC": "最常用的美股大盤。站上季線並創高代表多頭；跌破季線常被視為趨勢轉弱，可搭配 VIX 一起看風險情緒。",
         "^SOX": "半導體循環與 AI 資本支出的溫度計。觀察它領先或落後那斯達克；漲跌幅通常大於大盤。",
         "^IXIC": "對利率敏感，殖利率上升時通常承壓。比較它與費半、S&P 500 的強弱，可判斷市場風險偏好。",
         "^KS11": "韓國是記憶體與半導體出口大國，KOSPI 反映全球半導體景氣與外資對亞洲科技股的態度，也受韓元匯率影響。",
         "^N225": "日圓貶值通常有利出口股、日圓急升則不利；也反映亞洲風險情緒與日本央行政策預期。"}
TWREL = {"TXF": "台股避險與波段操作最常用的工具，外資與法人的期貨部位（多空單）也被視為籌碼面參考。換月前後成交量會轉移到下一個月份。",
         "^DJI": "道瓊以傳統產業為主，對台股電子股的直接牽動較小，主要反映整體風險情緒。",
         "^GSPC": "大漲大跌會影響外資風險偏好與台股隔日開盤情緒，其中科技權值股連動較高。",
         "^SOX": "對台股影響最直接：台積電、半導體設備、IC 設計、記憶體與 AI 伺服器供應鏈，常在費半大漲／大跌後隔日出現同向反應。",
         "^IXIC": "科技與 AI 風向球，與台股電子、AI 供應鏈連動性高。",
         "^KS11": "台韓同屬半導體與電子出口導向市場，記憶體與先進製程題材常同向；外資在亞洲科技股的資金調度也會互相影響。",
         "^N225": "同屬亞洲市場，日圓匯率與日本半導體設備、材料族群表現可作為亞洲科技股情緒參考。",
         "^TWII": "台股大盤，台積電權重很大，指數漲跌主要受電子權值股、外資買賣超與美股影響。"}
TAGMAP = {"多頭排列": "bull", "空頭排列": "bear", "盤整震盪": "range"}
INDEX_CKL = ["收盤站上月線（MA20）", "收盤站上季線（MA60）", "月線上彎", "MACD 柱狀體為正", "RSI 在 50～75 健康區", "距 52 週高點不到 10%"]

def calc_phase():
    """用加權指數與季線、半年線的相對位置與季線方向，推估景氣循環位置（價格面推測）"""
    try:
        c = yf.download("^TWII", period="2y", progress=False, auto_adjust=False)["Close"]
        c = (c.iloc[:, 0] if hasattr(c, "columns") else c).dropna()
        m60, m120 = c.rolling(60).mean(), c.rolling(120).mean()
        last, up60 = float(c.iloc[-1]), m60.iloc[-1] > m60.iloc[-11]
        if last > m60.iloc[-1]:
            ph = ("擴張期" if last > m120.iloc[-1] else "復甦期") if up60 else "趨緩期"
        else:
            ph = "趨緩期" if up60 else "衰退／築底期"
        return dict(phase=ph, last=round(last, 2), ma60=round(float(m60.iloc[-1]), 2), ma120=round(float(m120.iloc[-1]), 2))
    except Exception as e:
        print("景氣循環推估略過", e); return None

def adapt_market(mk):
    """把 extras.get_market 的結果整理成網頁格式，並加入景氣燈號與循環推估"""
    items = mk.get("items", [])
    ref = next((x["dates"] for x in items if len(x.get("dates") or []) >= 90), items[0]["dates"] if items else [])
    for x in items:
        ev = x.pop("ev", None) or {}
        x["about"], x["watch"], x["tw"] = x.pop("desc", ""), WATCH.get(x["sym"], ""), TWREL.get(x["sym"], "")
        if ev:
            x.update(t=TAGMAP.get(ev.get("tr"), "none"), ck=ev["ck"], w=ev["why"], r=ev["rsi"], a=ev["a"], z=ev["z"], h=ev["h"],
                     l=ev["l"], g5=ev["g5"], g20=ev["g20"], ckl=INDEX_CKL)
    n = cal.get_ndc()
    mk["ndc"] = dict(light=n["light"], score=n["score"], prev=None, date=n["d"] + " 公布") if n else None
    mk["cycle"], mk["dates"] = calc_phase(), ref
    return mk

IND_TIPS = [  # 重要經濟數據速查：看什麼、偏高／偏低通常的影響
 ("CPI 消費者物價指數", "通膨水準", "高於預期→降息預期降溫，科技與成長股承壓；低於預期→降息預期升溫，風險資產受惠。"),
 ("非農就業", "就業市場熱度", "過強→利率可能維持高檔；過弱→衰退疑慮；溫和最理想。"),
 ("FOMC 利率決策", "政策利率與展望", "看與預期的差距與談話語氣：鴿派利多成長股，鷹派壓抑估值。"),
 ("PCE 物價", "聯準會最重視的通膨指標", "走勢與 CPI 類似，影響降息時點預期。"),
 ("GDP 經濟成長", "整體經濟動能", "過熱引發升息擔憂，過弱引發衰退擔憂；『溫和成長』最有利股市。"),
 ("PPI 生產者物價", "上游成本與通膨領先訊號", "上升代表成本壓力，可能轉嫁到消費端。"),
 ("ISM／PMI 採購經理人指數", "製造業與服務業景氣（50 為榮枯線）", "高於 50 擴張；對台灣出口與電子族群具領先參考。"),
 ("零售銷售", "美國消費力道", "太強偏向升息疑慮，太弱代表消費降溫，影響消費與科技終端需求。"),
]
KEYS = r"Consumer Price Index|Employment Situation|Producer Price|Gross Domestic Product|Personal Income|Personal Consumption|FOMC|Federal Open Market|Retail Sales|Job Openings|Unemployment"
REL_TIP = [(r"Consumer Price", "CPI 通膨數據：與預期的差距決定降息預期，進而影響科技與成長股估值。"),
           (r"Employment Situation|Unemployment|Job", "就業數據：過熱使利率維持高檔、過冷引發衰退疑慮。"),
           (r"Producer Price", "PPI：反映上游成本，可作為後續通膨的領先參考。"),
           (r"Gross Domestic|Personal Income|Personal Consumption", "GDP／個人消費與 PCE：評估經濟動能與通膨，影響利率預期。"),
           (r"FOMC|Federal Open Market", "聯準會決策聲明：看利率決定與措辭變化，影響全球股債匯。"),
           (r"Retail", "零售銷售：反映消費力道。")]
FEEDS = [("BLS", "https://www.bls.gov/feed/bls_latest.rss"), ("Fed", "https://www.federalreserve.gov/feeds/press_monetary.xml"),
         ("BEA", "https://www.bea.gov/news/rss.xml")]

def get_releases():
    """官方最新公布（BLS／Fed／BEA 公開 RSS）；抓不到的來源會略過"""
    now, out = dt.datetime.now(dt.timezone.utc), []
    for src, url in FEEDS:
        try:
            root = ET.fromstring(requests.get(url, headers=UA, timeout=30).content)
        except Exception as e:
            print("公布資料略過", src, e); continue
        for it in root.iter("item"):
            title = html.unescape((it.findtext("title") or "").strip())
            if not re.search(KEYS, title, re.I):
                continue
            try:
                t = email.utils.parsedate_to_datetime(it.findtext("pubDate"))
                if t.tzinfo is None:
                    t = t.replace(tzinfo=dt.timezone.utc)
            except Exception:
                continue
            if (now - t).days > 8:
                continue
            desc = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", html.unescape(it.findtext("description") or ""))).strip()
            tip = next((v for k, v in REL_TIP if re.search(k, title, re.I)), "")
            out.append(dict(src=src, title=title, desc=desc[:260], link=it.findtext("link") or "", ts=t.timestamp(),
                            t=t.astimezone(TZ).strftime("%m/%d %H:%M"), tip=tip))
    out.sort(key=lambda x: -x["ts"])
    for x in out:
        x.pop("ts")
    return out[:8]
