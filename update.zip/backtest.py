"""訊號回測：過去幾年每種技術面狀態出現後，5／20 個交易日的平均報酬與勝率（歷史統計，不代表未來）→ docs/backtest.json
條件與 screener.evaluate 相同；進場價用「訊號隔天收盤」避免偷看未來；同一檔同一種訊號 10 個交易日內只算一次。"""
import os, json, datetime as dt
import numpy as np, pandas as pd

MIN_AVG_VOL, MIN_PRICE, COOL, HS = 500_000, 10, 10, (5, 20)
TAGS = ["breakout", "prep", "dip", "near", "weak"]
TZ = dt.timezone(dt.timedelta(hours=8))

def rsi(c, n=14):
    d = c.diff()
    up = d.clip(lower=0).ewm(alpha=1 / n, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / n, adjust=False).mean()
    return 100 - 100 / (1 + up / dn.replace(0, np.nan))

def tag_series(df):
    """逐日計算技術面狀態（向量化版 evaluate）。回傳 (tag Series, liquid Series)"""
    c, v = df["Close"], df["Volume"]
    ma5, ma20, ma60 = c.rolling(5).mean(), c.rolling(20).mean(), c.rolling(60).mean()
    macd = c.ewm(span=12, adjust=False).mean() - c.ewm(span=26, adjust=False).mean()
    hist = macd - macd.ewm(span=9, adjust=False).mean()
    r = rsi(c)
    hi20, lo60 = c.shift(1).rolling(20).max(), c.rolling(60).min()
    dd = c / c.rolling(120).max() - 1
    vr = v / v.shift(1).rolling(20).mean()
    liquid = (v.rolling(5).mean() >= MIN_AVG_VOL) & (c >= MIN_PRICE)
    trend = (c > ma20) & (ma20 > ma60) & (ma20 > ma20.shift(5))
    br = liquid & trend & (c > hi20) & (vr >= 1.5) & (hist > 0) & (hist > hist.shift(1)) & r.between(55, 80)
    prep = liquid & trend & (c >= hi20 * 0.97) & (c <= hi20) & (hist > 0) & r.between(50, 72)
    dip = (liquid & (dd <= -0.30) & (r.shift(1).rolling(5).min() <= 30) & (r > r.shift(1)) & (c > ma5)
           & (c > c.rolling(6).min()))
    near = liquid & (c <= lo60 * 1.05) & (r <= 40)
    weak = (c < ma20) & (ma20 < ma60) & (ma20 < ma20.shift(5))
    tag = pd.Series("none", index=c.index, dtype=object)
    for name, m in (("weak", weak), ("near", near), ("dip", dip), ("prep", prep), ("breakout", br)):
        tag[m.fillna(False)] = name
    return tag, liquid

def cooldown(mask):
    keep, last = np.zeros(len(mask), bool), -10 ** 9
    for i in np.flatnonzero(mask):
        if i - last >= COOL:
            keep[i] = True; last = i
    return keep

def collect(df, acc):
    df = df.dropna(subset=["Close", "Volume"])
    if len(df) < 200:
        return
    tag, liquid = tag_series(df)
    c, ix = df["Close"], df.index.values
    fwd = {h: (c.shift(-(h + 1)) / c.shift(-1) - 1).values for h in HS}
    for h in HS:
        ok = ~np.isnan(fwd[h])
        m0 = ok & liquid.values & (tag.values == "none")
        acc["base"][h].extend(zip(ix[m0], fwd[h][m0]))
        for t in TAGS:
            m = cooldown((tag.values == t) & ok)
            acc[t][h].extend(zip(ix[m], fwd[h][m]))

COST = 0.585   # 來回手續費 0.1425%×2 ＋ 證交稅 0.3%（%），未計滑價

def stat(lst, since=None):
    r = np.array([x[1] for x in lst if since is None or x[0] >= since], float)
    return r

def block(acc, since=None):
    def agg(k):
        o = {}
        for h in HS:
            r = stat(acc[k][h], since) * 100 - COST
            o[h] = r
        return o
    b = agg("base")
    base = dict(a5=round(float(b[5].mean()), 2), w5=round(float((b[5] > 0).mean() * 100), 1),
                a20=round(float(b[20].mean()), 2), w20=round(float((b[20] > 0).mean() * 100), 1)) if len(b[5]) >= 30 else None
    if not base:
        return None
    tags = {}
    for t in TAGS:
        r = agg(t)
        if len(r[20]) < 5:
            continue
        tags[t] = dict(n=int(len(r[20])), a5=round(float(r[5].mean()), 2), w5=round(float((r[5] > 0).mean() * 100), 1),
                       a20=round(float(r[20].mean()), 2), w20=round(float((r[20] > 0).mean() * 100), 1),
                       ex20=round(float(r[20].mean() - base["a20"]), 2), p10=round(float(np.percentile(r[20], 10)), 2))
    return dict(base=base, tags=tags)

def summarize(acc, n_stocks, years=3):
    since = np.datetime64(dt.datetime.now(TZ).date() - dt.timedelta(days=365))
    out = dict(updated=dt.datetime.now(TZ).strftime("%Y-%m-%d"), years=years, stocks=n_stocks, cost=COST, all=block(acc))
    y1 = block(acc, since)
    if y1:
        out["y1"] = y1
    return out

def new_acc():
    return {k: {h: [] for h in HS} for k in ["base"] + TAGS}

def main(limit=400, period="3y"):
    import yfinance as yf
    s = json.load(open("docs/stocks.json", encoding="utf-8"))["s"]
    top = sorted(((c, x) for c, x in s.items() if not x.get("e")), key=lambda kv: -(kv[1].get("tn") or 0))[:limit]
    tick = [c + (".TWO" if x.get("x") == "上櫃" else ".TW") for c, x in top]
    acc, n = new_acc(), 0
    for i in range(0, len(tick), 100):
        part = tick[i:i + 100]
        try:
            d = yf.download(part, period=period, group_by="ticker", progress=False, threads=True, auto_adjust=True)
        except Exception as e:
            print("下載失敗", e); continue
        for t in part:
            try:
                collect(d[t], acc); n += 1
            except Exception:
                pass
    res = summarize(acc, n)
    if not res.get("all"):
        print("❌ 回測樣本不足，不更新"); raise SystemExit(1)
    json.dump(res, open("docs/backtest.json", "w", encoding="utf-8"), ensure_ascii=False)
    print("回測完成", n, "檔", {k: v["n"] for k, v in res["all"]["tags"].items()})

if __name__ == "__main__":
    main()
