"""美股龍頭股追蹤 + 國際英文新聞（附中文翻譯與單字）"""
import re, html, time, email.utils, datetime as dt
import xml.etree.ElementTree as ET
import requests, yfinance as yf
from extras import claude_json, classify, CATS, UA, TZ, score_items, procon, pick_top10

# 想追蹤的美股：(代號, 中文名, 類別)。可自行增刪。
US_LIST = [
    ("NVDA", "輝達", "AI／半導體"), ("MSFT", "微軟", "科技巨頭"), ("AAPL", "蘋果", "科技巨頭"),
    ("GOOGL", "Alphabet 谷歌", "科技巨頭"), ("AMZN", "亞馬遜", "科技巨頭"), ("META", "Meta", "科技巨頭"),
    ("TSLA", "特斯拉", "科技巨頭"), ("SPCX", "SpaceX", "科技巨頭"), ("AVGO", "博通", "AI／半導體"),
    ("TSM", "台積電 ADR", "AI／半導體"), ("ORCL", "甲骨文", "軟體雲端"), ("NFLX", "網飛", "科技巨頭"),
    ("PLTR", "Palantir", "軟體雲端"), ("AMD", "超微 AMD", "AI／半導體"), ("MU", "美光", "AI／半導體"),
    ("ASML", "艾司摩爾", "AI／半導體"), ("QCOM", "高通", "AI／半導體"), ("TXN", "德州儀器", "AI／半導體"),
    ("AMAT", "應用材料", "AI／半導體"), ("LRCX", "科林研發", "AI／半導體"), ("KLAC", "科磊", "AI／半導體"),
    ("ARM", "安謀 ARM", "AI／半導體"), ("MRVL", "邁威爾", "AI／半導體"), ("INTC", "英特爾", "AI／半導體"),
    ("CRM", "Salesforce", "軟體雲端"), ("ADBE", "Adobe", "軟體雲端"), ("NOW", "ServiceNow", "軟體雲端"),
    ("INTU", "財捷 Intuit", "軟體雲端"), ("IBM", "IBM", "軟體雲端"), ("CSCO", "思科", "軟體雲端"),
    ("UBER", "優步", "科技巨頭"), ("BRK-B", "波克夏", "金融"), ("JPM", "摩根大通", "金融"),
    ("V", "Visa", "金融"), ("MA", "萬事達卡", "金融"), ("BAC", "美國銀行", "金融"),
    ("WFC", "富國銀行", "金融"), ("GS", "高盛", "金融"), ("AXP", "美國運通", "金融"),
    ("WMT", "沃爾瑪", "消費"), ("COST", "好市多", "消費"), ("HD", "家得寶", "消費"),
    ("PG", "寶僑", "消費"), ("KO", "可口可樂", "消費"), ("PEP", "百事", "消費"),
    ("MCD", "麥當勞", "消費"), ("DIS", "迪士尼", "消費"), ("LLY", "禮來", "醫療"),
    ("JNJ", "嬌生", "醫療"), ("UNH", "聯合健康", "醫療"), ("ABBV", "艾伯維", "醫療"),
    ("MRK", "默克", "醫療"), ("ABT", "亞培", "醫療"), ("ISRG", "直覺外科", "醫療"),
    ("TMO", "賽默飛", "醫療"), ("XOM", "埃克森美孚", "能源工業"), ("CVX", "雪佛龍", "能源工業"),
    ("GE", "GE 航太", "能源工業"), ("CAT", "開拓重工", "能源工業"), ("LIN", "林德", "能源工業"),
    ("BA", "波音", "能源工業"),
]

EN_FEEDS = [("CNBC Top News", "https://www.cnbc.com/id/100003114/device/rss/rss.html"),
            ("CNBC Economy", "https://www.cnbc.com/id/20910258/device/rss/rss.html"),
            ("CNBC Technology", "https://www.cnbc.com/id/19854910/device/rss/rss.html"),
            ("CNBC World", "https://www.cnbc.com/id/100727362/device/rss/rss.html"),
            ("MarketWatch", "https://feeds.content.dowjones.io/public/rss/mw_topstories"),
            ("BBC Business", "https://feeds.bbci.co.uk/news/business/rss.xml")]

CAT_EN = [("央行利率", r"\bFed\b|rate cut|rate hike|interest rate|Powell|\bECB\b|\bBOJ\b|central bank|hawkish|dovish|monetary easing|quantitative easing"),
          ("通膨經濟數據", r"inflation|\bCPI\b|\bPCE\b|jobs report|payrolls|unemployment|\bGDP\b|recession|\bPMI\b|retail sales|economy"),
          ("貿易關稅", r"tariff|trade war|export control|sanction|trade deal|trade talks|embargo"),
          ("AI與半導體", r"Nvidia|\bAI\b|chip|semiconductor|TSMC|Micron|data center|\bHBM\b|artificial intelligence"),
          ("科技公司", r"Apple|Microsoft|Google|Alphabet|Amazon|\bMeta\b|Tesla|OpenAI|Intel|SpaceX|Netflix"),
          ("公司財報", r"earnings|revenue|profit|guidance|dividend|quarterly|forecast"),
          ("能源原物料", r"\boil\b|crude|OPEC|natural gas|\bgold\b|copper|commodit"),
          ("地緣政治", r"\bwar\b|Israel|Iran|Ukraine|Russia|Taiwan|missile|attack|election|Trump|Gaza|North Korea|China"),
          ("匯率債市", r"dollar|\byen\b|yuan|Treasury|yield|\bbond|currency"),
          ("市場動態", r"stocks|Wall Street|Nasdaq|S&P|\bDow\b|rally|selloff|market")]
UPW = re.compile(r"surge|soar|jump|rally|record|beat|gain|rise|climb|boost|strong|upgrade|rebound|optimis", re.I)
DNW = re.compile(r"plunge|slump|fall|drop|tumble|miss|slash|weak|slide|fear|crash|warn|downgrade|selloff|worr|cut jobs|layoff", re.I)
FLIPW = re.compile(r"delay|pause|cancel|ease|lift|truce|deal|ceasefire|relief|soften", re.I)
RULES_EN = [  # (關鍵字, 固定方向或None, 可能影響族群, 傳導邏輯, 利弊代號)
    (r"rate cut|cuts? rates|dovish|monetary easing|quantitative easing|stimulus", "偏多", "成長股、科技股、營建", "資金成本下降，有利股市估值，成長股通常最受惠", "cut"),
    (r"rate hike|raises? rates|hawkish|higher for longer|hot inflation|inflation (rises|accelerat|jump|surge)", "偏空", "成長股、科技股（銀行等金融股相對受惠）", "資金成本上升，壓抑股市估值，科技股通常較敏感", "hike"),
    (r"tariff|export control|sanction|trade war|embargo|\\bban(s|ned)?\\b", "偏空", "電子、半導體、航運、出口產業", "貿易限制增加成本與訂單不確定性，台灣出口導向產業較敏感", "tariff"),
    (r"oil (price|prices)? ?(surge|jump|spike|soar|rise)|crude (surge|jump|spike|soar|rise)", "偏空", "航空、運輸、塑化下游（石油相關族群相對受惠）", "油價上漲推升成本與通膨壓力", "oilup"),
    (r"oil (price|prices)? ?(fall|drop|slide|plunge|tumble)|crude (fall|drop|slide|plunge|tumble)", "偏多", "航空、運輸、塑化下游", "油價下跌降低成本、減輕通膨壓力", "oildown"),
    (r"\\bwar\\b|missile|attack|invasion|escalat|airstrike", "偏空", "航運、油價敏感族群；避險情緒升高", "地緣風險升高通常拉大市場波動、資金轉向避險", "geo"),
    (r"recession|layoffs?|job cuts|default|bankruptcy|credit crunch", "偏空", "景氣循環股、金融股", "景氣或信用風險升高，市場風險偏好下降", "recess"),
    (r"Nvidia|\\bAI\\b|chip|semiconductor|TSMC|Micron|data center|\\bHBM\\b", None, "AI 供應鏈、半導體（台積電、伺服器、PCB 等相關族群）", "AI 與半導體消息會牽動台股電子權值股情緒", "ai"),
    (r"Apple|Microsoft|Google|Alphabet|Amazon|\\bMeta\\b|Tesla|Intel", None, "美股科技巨頭與台灣相關供應鏈", "科技巨頭財報與資本支出會影響台灣供應鏈訂單預期", "tech"),
    (r"earnings|revenue|profit|guidance", None, "相關公司與同產業", "財報與財測好壞會影響該公司及同業估值", "earn"),
    (r"\\boil\\b|crude|OPEC|natural gas", None, "能源、塑化、航運", "能源價格波動影響成本結構與通膨預期", "energy"),
    (r"dollar|\\byen\\b|yuan|Treasury|yield", None, "出口業、壽險、金融股", "匯率與殖利率變動影響外資流向與企業匯兌損益", "fx"),
    (r"stocks|Wall Street|Nasdaq|S&P|\\bDow\\b|market", None, "整體台股", "美股走勢通常影響台股隔日開盤情緒", "mkt"),
]

def en_rule(x):
    t = x["title"]
    x["cat"] = classify(t, CAT_EN)
    x.update(dir="中性", sec="", im="", pro="", con="")
    for pat, d, sec, why, key in RULES_EN:
        if re.search(pat, t, re.I):
            if d is None:
                a, b = len(UPW.findall(t)), len(DNW.findall(t))
                d = "偏多" if a > b else "偏空" if b > a else "中性"
            elif FLIPW.search(t):
                d, why = {"偏多": "偏空", "偏空": "偏多"}[d], why + "（標題含緩和／延後字眼，已反向判斷）"
            x.update(dir=d, sec=sec, im=why + "。（規則式推測，可能判斷錯誤）", _hit=1)
            break
            break
    return x

# 美股龍頭 → 台灣相關族群（財報結果對台股供應鏈的連動參考）
TW_CHAIN = {"NVDA": "AI 伺服器、先進封裝、散熱與 PCB 供應鏈", "AAPL": "蘋果供應鏈（組裝、光學、被動元件）", "MSFT": "雲端與 AI 伺服器供應鏈",
            "GOOGL": "雲端與 AI 伺服器供應鏈", "AMZN": "雲端伺服器與網通供應鏈", "META": "AI 伺服器與網通供應鏈", "TSLA": "電動車與車用電子供應鏈",
            "AVGO": "網通晶片與 AI 客製化晶片供應鏈", "TSM": "台積電與先進製程供應鏈", "AMD": "AI／伺服器晶片供應鏈", "MU": "記憶體與半導體封測族群",
            "ASML": "半導體設備族群", "AMAT": "半導體設備族群", "LRCX": "半導體設備族群", "KLAC": "半導體設備族群", "QCOM": "手機晶片與網通供應鏈",
            "INTC": "PC 與伺服器供應鏈", "SPCX": "衛星與低軌通訊相關題材", "TXN": "類比晶片與車用電子", "ARM": "IP 與晶片設計族群"}

def get_us(evaluate):
    syms = [s for s, _, _ in US_LIST]
    try:
        d = yf.download(syms, period="1y", group_by="ticker", progress=False, threads=True, auto_adjust=True)
    except Exception as e:
        print("美股個股失敗", e); return dict(items=[], dates=[])
    items, ref, t0 = [], None, time.time()
    for sym, zh, cat in US_LIST:
        try:
            df = d[sym].dropna(subset=["Close"]); c = df["Close"]
            if len(c) < 3:
                continue
            try:
                ev = evaluate(df.dropna(subset=["Close", "Volume"])) or {}
            except Exception:
                ev = {}
            last = float(c.iloc[-1])
            g = lambda n: round((last / float(c.iloc[-n - 1]) - 1) * 100, 2) if len(c) > n else None
            it = dict(sym=sym, n=zh, cat=cat, c=round(last, 2), cg=round(last - float(c.iloc[-2]), 2), p=g(1), g5=g(5), g20=g(20),
                      h=round(float(c.iloc[-250:].max()), 2), l=round(float(c.iloc[-250:].min()), 2),
                      t=ev.get("tag", "none"), r=ev.get("rsi"), ck=ev.get("ck", ""), w=ev.get("why", []),
                      b=ev.get("buy", ""), s=ev.get("stop", 0), a=ev.get("ma20"), z=ev.get("ma60"),
                      hist=[round(float(x), 2) for x in c.iloc[-100:]], cap=0)
            if time.time() - t0 < 150:
                try:
                    fi = yf.Ticker(sym).fast_info
                    it["cap"] = float(getattr(fi, "market_cap", None) or fi["marketCap"] or 0)
                except Exception:
                    pass
            if ref is None or len(c) > len(ref):
                ref = c.index
            items.append(it)
        except Exception as e:
            print("美股略過", sym, e)
    if any(x["cap"] for x in items):
        items.sort(key=lambda x: -x["cap"])
    er = get_earnings(items, d)
    return dict(items=items, dates=[x.strftime("%m-%d") for x in ref[-100:]] if ref is not None else [], er=er)

def get_earnings(items, d):
    """追蹤個股的財報／法說：即將公布日期、最近一次結果（EPS 驚喜）與公布前後兩日股價反應"""
    up, res, today, t0 = [], [], dt.date.today(), time.time()
    for it in items:
        if time.time() - t0 > 200:
            break
        try:
            e = yf.Ticker(it["sym"]).get_earnings_dates(limit=8)
            if e is None or e.empty:
                continue
            c = d[it["sym"]]["Close"].dropna()
            idx = [x.date() for x in c.index]
            nxt, last = None, None
            for ts, row in sorted(e.iterrows(), key=lambda r: r[0]):
                day = ts.date()
                rep = row.get("Reported EPS")
                if day >= today and (rep != rep):            # 尚未公布
                    nxt = nxt or day
                elif rep == rep and day <= today:
                    last = dict(day=day, est=row.get("EPS Estimate"), act=rep, sur=row.get("Surprise(%)"))
            if nxt and (nxt - today).days <= 21:
                up.append(dict(sym=it["sym"], n=it["n"], d=str(nxt), tw=TW_CHAIN.get(it["sym"], "")))
            if last and (today - last["day"]).days <= 30:
                rx = None
                if last["day"] in idx:
                    i = idx.index(last["day"])
                    if i >= 1:
                        j = min(i + 1, len(c) - 1)
                        rx = round(float(c.iloc[j] / c.iloc[i - 1] - 1) * 100, 2)
                f = lambda v: None if v is None or v != v else round(float(v), 2)
                sur, r = f(last["sur"]), dict(sym=it["sym"], n=it["n"], d=str(last["day"]), est=f(last["est"]), act=f(last["act"]), sur=f(last["sur"]), rx=rx, tw=TW_CHAIN.get(it["sym"], ""))
                r["note"] = er_note(sur, rx)
                res.append(r)
                it["er"] = dict(last=r)
            it.setdefault("er", {})["next"] = str(nxt) if nxt else ""
        except Exception as ex:
            print("財報資料略過", it["sym"], ex)
    up.sort(key=lambda x: x["d"]); res.sort(key=lambda x: x["d"], reverse=True)
    return dict(up=up, res=res)

def er_note(sur, rx):
    """財報結果對股價的解讀（規則式）"""
    if sur is None and rx is None:
        return ""
    if sur is not None and rx is not None:
        if sur > 0 and rx > 0:
            return "EPS 優於預期，股價正面反應；通常帶動同產業與台灣供應鏈情緒。"
        if sur > 0 and rx <= 0:
            return "EPS 雖優於預期但股價下跌，市場可能更在意財測、毛利率或估值，屬『利多出盡』情境。"
        if sur <= 0 and rx > 0:
            return "EPS 低於預期但股價上漲，可能因財測或展望優於擔憂。"
        return "EPS 不如預期且股價下跌，可能拖累同產業與台灣供應鏈情緒。"
    return "EPS 優於預期。" if (sur or 0) > 0 else "EPS 不如預期。" if sur is not None else ""

def cut(s, n=300):
    if len(s) <= n:
        return s
    s = s[:n]
    i = max(s.rfind(". "), s.rfind("? "), s.rfind("! "))
    return s[:i + 1] if i > 80 else s.rstrip() + "…"

def get_enews():
    now, seen, items = dt.datetime.now(dt.timezone.utc), set(), []
    for src, url in EN_FEEDS:
        try:
            root = ET.fromstring(requests.get(url, headers=UA, timeout=30).content)
        except Exception as e:
            print("英文新聞失敗", src, e); continue
        n = 0
        for it in root.iter("item"):
            title = html.unescape((it.findtext("title") or "").strip())
            desc = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", html.unescape(it.findtext("description") or ""))).strip()
            try:
                t = email.utils.parsedate_to_datetime(it.findtext("pubDate"))
                if t.tzinfo is None:
                    t = t.replace(tzinfo=dt.timezone.utc)
            except Exception:
                continue
            key = re.sub(r"\W", "", title.lower())[:30]
            if not title or key in seen or (now - t).total_seconds() > 48 * 3600:
                continue
            seen.add(key); n += 1
            items.append(dict(src=src, title=title, sum=cut(desc), link=it.findtext("link") or "",
                              ts=t.timestamp(), t=t.astimezone(TZ).strftime("%m/%d %H:%M")))
            if n >= 8:
                break
    for x in items:
        en_rule(x)
    items = score_items(items)
    cand, brief, mode = items[:25], [], "en"
    chosen = None
    if cand:
        lines = "\n".join(f"{i}. [{x['cat']}] {x['title']} || {x['sum']}" for i, x in enumerate(cand))
        prompt = ("以下是英文財經新聞（標題 || 摘要）。請挑出對台股與美股最重要的 10 則，依重要程度由高到低排序，只輸出 JSON，格式："
                  '{"brief":["今日國際財經重點，繁體中文，3~4句"],"items":[{"i":編號,"imp":重要度1到5,"zt":"標題的繁體中文翻譯",'
                  '"zs":"摘要的繁體中文翻譯，沒有摘要則空字串","vo":[{"w":"英文單字或片語","zh":"中文意思"}],'
                  '"cat":"從這個清單選一個：' + "、".join(CATS) + '","dir":"偏多|偏空|中性（對股市的可能影響方向）",'
                  '"sec":"可能受影響的產業或族群","im":"對台股與美股可能的影響與傳導邏輯，2句內，語氣保守並說明不確定性",'
                  '"pro":"有利之處（利）","con":"不利或風險（弊）"}]}。'
                  "vo 請挑 2~4 個對英文學習者有用的財經單字或片語。翻譯要通順準確，不要加入原文沒有的資訊，不要推薦買賣個股。\n\n" + lines)
        res = claude_json(prompt, 8000)
        if res:
            chosen = []
            for o in res.get("items", []):
                try:
                    x = cand[o["i"]]
                    if x in chosen:
                        continue
                    x.update(zt=str(o.get("zt", "")), zs=str(o.get("zs", "")),
                             vo=[dict(w=str(v["w"]), zh=str(v["zh"])) for v in o.get("vo", [])][:4],
                             imp=max(1, min(5, int(o.get("imp", 3)))))
                    if o.get("cat") in CATS:
                        x["cat"] = o["cat"]
                    if o.get("dir") in ("偏多", "偏空", "中性"):
                        x["dir"] = o["dir"]
                    if o.get("im"):
                        x.update(sec=str(o.get("sec", "")), im=str(o["im"]), pro=str(o.get("pro", "")), con=str(o.get("con", "")))
                    chosen.append(x)
                except Exception:
                    continue
            if len(chosen) >= 5:
                mode, brief, items = "ai", [str(s) for s in res.get("brief", [])], chosen
    return dict(mode=mode, brief=brief, items=pick_top10(items))
