"""自選股提醒：讀取專案根目錄的 watchlist.txt，每次完整分析後比對變化並推播（Discord／Telegram）
格式（每行一檔，# 開頭為註解；可加到價提醒）：
    2330
    2317 >200 <160
    NVDA >250"""
import os, re, json

LABEL = {"breakout": "技術面偏多（突破）", "prep": "接近突破", "dip": "跌深出現止跌跡象", "near": "接近低檔支撐", "weak": "弱勢走勢", "none": "無明確訊號"}

def load_watch(path="watchlist.txt"):
    out = []
    try:
        for ln in open(path, encoding="utf-8"):
            ln = ln.split("#")[0].strip()
            if not ln:
                continue
            p = ln.split()
            up = dn = None
            for t in p[1:]:
                m = re.match(r"([<>])\s*(\d+(?:\.\d+)?)", t)
                if m:
                    if m.group(1) == ">": up = float(m.group(2))
                    else: dn = float(m.group(2))
            out.append(dict(k=p[0].upper(), up=up, dn=dn))
    except FileNotFoundError:
        pass
    return out

def check(watch, allst, us_items, old_s, old_us):
    """回傳提醒文字清單"""
    msgs = []
    usm = {u["sym"]: u for u in us_items}
    olu = {u["sym"]: u for u in old_us}
    for w in watch:
        k = w["k"]
        if k in allst:
            x, o = allst[k], (old_s or {}).get(k, {})
            name, c, p, tag, oc, ot = f"{x['name']}({k})", x["close"], x["pct"], x["tag"], o.get("c"), o.get("t")
            stop, ostop = x.get("stop"), o.get("s")
        elif k in usm:
            u, o = usm[k], olu.get(k, {})
            name, c, p, tag, oc, ot = f"{u['n']}({k})", u["c"], u.get("p") or 0, u.get("t", "none"), o.get("c"), o.get("t")
            stop, ostop = u.get("s"), o.get("s")
        else:
            continue
        if ot and tag != ot and tag in ("breakout", "prep", "dip"):
            msgs.append(f"🚀 {name} 出現「{LABEL[tag]}」（收 {c}，{p:+.2f}%）")
        elif ot and tag != ot and tag == "weak":
            msgs.append(f"⛔ {name} 轉為「弱勢走勢」（收 {c}，{p:+.2f}%）")
        if abs(p) >= 5:
            msgs.append(f"{'📈' if p > 0 else '📉'} {name} 單日 {p:+.2f}%（收 {c}）")
        if ostop and oc is not None and oc >= ostop and c < ostop:
            msgs.append(f"⚠️ {name} 收盤 {c} 跌破技術價位 {ostop}")
        if w["up"] is not None and c >= w["up"] and (oc is None or oc < w["up"]):
            msgs.append(f"🎯 {name} 收盤 {c} 到達上緣價 {w['up']}")
        if w["dn"] is not None and c <= w["dn"] and (oc is None or oc > w["dn"]):
            msgs.append(f"🎯 {name} 收盤 {c} 跌到下緣價 {w['dn']}")
    return msgs

def alert_text(msgs, date):
    return f"🔔 自選股提醒（{date} 收盤）\n" + "\n".join(msgs) + "\n⚠️ 個人研究用整理，非投資建議" if msgs else ""
